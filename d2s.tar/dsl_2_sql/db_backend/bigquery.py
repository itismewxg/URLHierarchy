#pylint: disable=missing-docstring,invalid-name,no-self-use

import re
import xlate_sql_expr as myexpr

class BigQueryBackend(object):
    type_map = {'long': 'INT64', 'int':  'INT64', 'double': 'FLOAT64'}

    def __init__(self, app_info=None):
        self._app_info = app_info
        self._table = None
        self._schema = None

    def set_table(self, tab, schema):
        self._table = tab
        self._schema = schema


    def is_time_type(self, type_name):
        return type_name in ['date', 'timestamp']

    def get_ts_in_millis(self, col_name):
        expr = myexpr.gen_call_expr('UNIX_MILLIS',
                                    [myexpr.ExprOpndColumnRef(col_name)])
        return expr


    def get_ts_in_seconds(self, col_name):
        expr = myexpr.gen_call_expr('UNIX_SECONDS',
                                    [myexpr.ExprOpndColumnRef(col_name)])
        return expr


    def cvt_to_native_type(self, ty):
        return self.type_map.get(ty.lower(), ty)


    def emit_column_name(self, col_name):
        #handle nested and repeated columns
        if not '.' in col_name:
            return self._emit_column_name_helper(col_name)

        name_parts = [self._emit_column_name_helper(x) for x in col_name.split('.')]
        return '.'.join(name_parts)


    def emit_table_name(self, tab_name):
        return "`%s`" % tab_name


    def _emit_column_name_helper(self, name):
        if not re.match(r'^\w+$', name):
            return '`' + name + '`'
        return name


    def emit_pretty_print_select_all_sql(self, name):
        return "SELECT TO_JSON_STRING(t) FROM `%s` AS t" % name

    def cmp_ts_column_using_str(self):
        return True
