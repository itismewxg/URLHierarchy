import re
import xlate_sql_expr as myexpr

from dsl_2_sql.db_backend.clickhouse_client import ClickhouseClient


class ClickhouseBackend(object):
    type_map = {'long': 'Int64', 'int': 'Int64', 'double': 'Float64'}

    def __init__(self, app_info=None):
        self._app_info = app_info
        self._table = None
        self._schema = None

    def set_table(self, tab, schema):
        self._table = tab
        self._schema = schema

    def get_ts_in_seconds(self, col_name):
        expr = myexpr.gen_call_expr('toInt64', [myexpr.ExprOpndColumnRef(col_name)])
        return expr

    def get_ts_in_millis(self, col_name):
        expr = myexpr.gen_call_expr('toInt64', [myexpr.ExprOpndColumnRef(col_name)])
        return myexpr.gen_binary_expr(myexpr.OPR_MUL,
                                      expr,
                                      myexpr.ExprOpndLiteral(1000))

    def cvt_to_native_type(self, ty):
        return self.type_map.get(ty.lower(), ty)

    def _emit_column_name_helper(self, name):
        if not re.match(r'^\w+$', name):
            return '`' + name + '`'
        return name

    def emit_column_name(self, col_name):
        #handle nested and repeated columns
        if not '.' in col_name:
            return self._emit_column_name_helper(col_name)

        name_parts = [self._emit_column_name_helper(x) for x in col_name.split('.')]
        return '.'.join(name_parts)

    def emit_column_representation(self, col):
        return col.name

    def emit_table_name(self, tab_name):
        return ClickhouseClient.parse_fully_qualified_table(tab_name)

    def emit_pretty_print_select_all_sql(self, tab_name):
        # `FORMAT JSON` will automatically be appended
        return "SELECT * FROM %s" % self.emit_table_name(tab_name)

    @staticmethod
    def is_time_type(type_name):
        return type_name in ['Date', 'DateTime']



