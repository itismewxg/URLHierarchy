import json
from copy import deepcopy

import requests
from requests import HTTPError


class ClickhouseClient:
    # This keyword is disallowed in queries
    FORMAT_KEYWORD = 'FORMAT'

    # This string is appended to queries to return them in SQL format
    FORMAT_STRING = FORMAT_KEYWORD + ' JSON'

    JSON_USERNAME_KEY = 'username'
    JSON_PASSWORD_KEY = 'password'
    JSON_HOST_KEY = 'host'

    DATABASE_PARAM = 'database'

    def __init__(self, chconf):
        self._set_chconf(chconf)

    def _set_chconf(self, chconf: dict):
        for key, val in chconf.items():
            if self.JSON_HOST_KEY not in val:
                raise ValueError('chconf file missing required key for table `{}` ('
                                 'must have `{}`)'
                                 .format(key, self.JSON_HOST_KEY))

        self.chconf = deepcopy(chconf)

    def _get_table_conf(self, conf_specifier: str) -> dict:
        """
        Fetches the specified configuration object from self.chconf.

        conf_specifier can be any of the following:
        - Instance name (e.g. 'timeseries-standby-server')
        - Fully qualified database (e.g. 'timeseries-standby-server.timeseries')
        - Fully qualified table (e.g. 'timeseries-standby-server.timeseries.wellsfargo')

        :param conf_specifier: specifies which conf options to use
        :return: a dict with a `host` key and optional `username` and `password` keys
        """
        parts = conf_specifier.split('.')

        # Check parts in decreasing order of specificity. E.g., for `timeseries-standby-server.timeseries.wellsfargo`,
        # check:
        # 1. `timeseries-standby-server.timeseries.wellsfargo`
        # 2. `timeseries-standby-server.timeseries`
        # 3. `timeseries-standby-server`
        for i in range(len(parts)):
            if i == 0:
                partial_table = conf_specifier
            else:
                partial_table = '.'.join(parts[:-i])

            try:
                return self.chconf[partial_table]
            except KeyError:
                continue

        raise ValueError('No entry in chconf found for conf specifier {}'.format(conf_specifier))

    def do_query(self, sql: str, conf_specifier: str):
        """
        Perform the given query using the given conf.

        :param sql: must perform a query on the given table.
        :param conf_specifier: see _get_table_conf()
        """

        if self.FORMAT_KEYWORD in sql:
            sql_with_format = sql
        else:
            sql_with_format = sql + ' ' + self.FORMAT_STRING

        conf = self._get_table_conf(conf_specifier)
        host = conf[self.JSON_HOST_KEY]
        username = conf.get(self.JSON_USERNAME_KEY, None)
        password = conf.get(self.JSON_PASSWORD_KEY, '')

        if username is not None:
            r = requests.post(host,
                              auth=(username, password),
                              data=sql_with_format)
        else:
            r = requests.post(host, data=sql_with_format)

        try:
            r.raise_for_status()
        except HTTPError as e:
            print('ClickhouseClient got HTTPError when executing query:\n{}'.format(e.response.text))
            raise

        return r.json()

    @staticmethod
    def assert_specifies_db(table):
        """
        A database is indicated by a `.` in the table name
        """
        if '.' not in table:
            raise ValueError('Table name must specify the database '
                             '(format is <database>.<table_name>). '
                             'Got {} instead'.format(table))

    @staticmethod
    def parse_fully_qualified_table(fully_qualified_table: str) -> str:
        """
        Parses a fully qualified table (e.g. 'timeseries-standby-server.timeseries.wellsfargo') to just
        <database>.<tablename> (e.g. 'timeseries.wellsfargo').

        This function should be called before inserting a table name into any SQL passed to do_query()
        """
        parts = fully_qualified_table.split('.')
        if len(parts) <= 2:
            return fully_qualified_table
        else:
            # Select just the last 2 parts
            return '.'.join(parts[-2:])
