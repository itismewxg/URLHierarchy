#pylint: disable=missing-docstring,invalid-name

from .bigquery import BigQueryBackend
from .postgresql import PostgresqlBackend
from .clickhouse import ClickhouseBackend

class BackendDB(object):
    types = ['long', 'int', 'float', 'double']

    def __init__(self, backend_name, app_info=None):
        bn = backend_name if backend_name is not None else "bigquery"
        if bn == 'bigquery':
            self._backend = BigQueryBackend(app_info=app_info)
        elif bn == 'postgresql':
            self._backend = PostgresqlBackend(app_info=app_info)
        elif bn == 'clickhouse':
            self._backend = ClickhouseBackend(app_info=app_info)
        else:
            assert False


    def set_table(self, tab, schema):
        self._backend.set_table(tab, schema)


    def get_ts_in_millis(self, col_name):
        #assert self.is_col_about_ts(col_name)
        return self._backend.get_ts_in_millis(col_name)


    def get_ts_in_seconds(self, col_name):
        #assert self.is_col_about_ts(col_name)
        return self._backend.get_ts_in_seconds(col_name)


    def cvt_to_native_type(self, type_name):
        assert type_name.lower() in self.types

        get_canonical_ty = getattr(self._backend, 'cvt_to_native_type', None)
        if get_canonical_ty is not None:
            return get_canonical_ty(type_name)
        return type_name


    def emit_column_name(self, col_name):
        func = getattr(self._backend, 'emit_column_name', None)
        if func is not None:
            return func(col_name)
        return col_name


    def emit_column_representation(self, col) -> str:
        func = getattr(self._backend, 'emit_column_representation', None)
        if func is not None:
            return func(col)
        return str(col.index)


    def emit_table_name(self, tab_name):
        func = getattr(self._backend, 'emit_table_name', None)
        if func is not None:
            return func(tab_name)
        return tab_name


    def emit_pretty_print_select_all_sql(self, tab_name):
        func = getattr(self._backend, 'emit_pretty_print_select_all_sql', None)
        if func is not None:
            return func(tab_name)

        sql = "SELECT * FROM %s" % tab_name
        return sql

    def cmp_ts_column_using_str(self):
        """
        return True iff we are comparing timestamp-column with timestamp literal
        using the form like: "column-name cmp timestamp-str-liter", e.g.
           e.g myts_column > "2019-05-23 4:15:00"

        if this function return False, we are going to reply on backdb specific
        function for timestamp comparison, e.g:
            UNIX_MILLIS(_timestamp) >= 1558633385000
        """
        func = getattr(self._backend, 'cmp_ts_column_using_str', None)
        if func is not None:
            return func()
        return False
