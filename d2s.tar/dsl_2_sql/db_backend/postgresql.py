import re
import xlate_sql_expr as myexpr

class PostgresqlBackend(object):
    type_map = {'long': 'BIGINT', 'int':  'INTEGER', 'double': 'DOUBLE PRECISION'}

    def __init__(self, app_info=None):
        self._app_info = app_info
        self._table = None
        self._schema = None

    def set_table(self, tab, schema):
        self._table = tab
        self._schema = schema


    def is_time_type(self, type_name):
        return type_name in ['date', 'timestamp']

    def get_ts_in_millis(self, col_name):                                          
        func_arg = myexpr.gen_versatile_list(
                [myexpr.gen_keyword('epoch'),
                    myexpr.gen_keyword('from'),
                    myexpr.ExprOpndColumnRef(col_name)])                                  

        extract_call = myexpr.gen_call_expr('EXTRACT', [func_arg])                   
        mul_expr = myexpr.gen_binary_expr(myexpr.OPR_MUL,                            
                                          extract_call,                             
                                          myexpr.ExprOpndLiteral(1000))            
        return mul_expr   

    def get_ts_in_seconds(self, col_name):
        func_arg = myexpr.gen_nary_or_expr(
                [myexpr.gen_keyword('epoch'), 
                    myexpr.gen_keyword('from'), 
                    myexpr.ExprOpndColumnRef(col_name)])                                  

        extract_call = myexpr.gen_call_expr('EXTRACT', func_arg)                   
        floor_expr = myexpr.gen_call_expr('FLOOR', [extract_call])                             
        return floor_expr   

    def cvt_to_native_type(self, ty):
        return self.type_map.get(ty.lower(), ty)


    def _emit_column_name_helper(self, name):
        if not re.match(r'^\w+$', name):
            return '`' + name + '`'
        return name


    def emit_column_name(self, col_name):
        #handle nested and repeated columns
        if not '.' in col_name:
            return self._emit_column_name_helper(col_name)

        name_parts = [self._emit_column_name_helper(x) for x in col_name.split('.')]
        return '.'.join(name_parts)


    def emit_table_name(self, tab_name):
        return tab_name

    def emit_pretty_print_select_all_sql(self, name):
        return "SELECT ROW_TO_JSON(t) FROM %s AS t" % name

