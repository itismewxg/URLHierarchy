#!/usr/bin/env python

import sys
import os
import json
import logging
import logging.handlers

wdir = os.path.dirname(os.path.realpath(__file__))
sys.path.append(wdir + "/..")
sys.path.append(wdir + "/../..")

from xlate_config import AppConfig, XlateContext
from xlate_schema import Schema
from xlate_translate import DSL2SQL

def main():

    handler = logging.handlers.RotatingFileHandler('test.log', \
        maxBytes=(200*1024*1024), backupCount=5)
    fmt = '%(asctime)s - %(filename)s:%(lineno)s - %(name)s - %(message)s'
    formatter = logging.Formatter(fmt)
    handler.setFormatter(formatter)

    logger = logging.getLogger(None)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

    with open(sys.argv[1]) as f:
        dsl = json.loads(f.read())
        schema = Schema('wtf_table', {'@timestamp': 'date', 'isAttack': 'bool' })
        ctx = XlateContext(AppConfig(wdir + "/app.conf"), schema)

        sql, qmode, column_map, additional_info = DSL2SQL(dsl, ctx)
        print ("sql:\n", sql)
        print ("\nqmode: ", qmode)
        print ("\nadditional_info:", str(additional_info))
        print ("\nclumn_map:\n")
        if column_map is None:
            print("None")
        else:
            for k in column_map:
                print("%s -> %s" % (k, column_map[k]))

main()
