import sys
import os
import json

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")

from xlate_translate import DSL2SQL
import xlate_condition as mycond
import xlate_sql_expr as myexpr
from xlate_config import XlateContext, AppConfig
from xlate_schema import Schema

def normalize_sql_str(sql_stmt):
    tokens = sql_stmt.replace('\n', ' ').split(' ')
    tokens = [x for x in tokens if x != '']
    return ' '.join(tokens)

def dsl_2_sql_test(dsl, e_sql=None, e_qmode=None):
    schema = Schema('mytable', {'@timestamp': 'date', 'isAttack': 'bool' })
    wdir = os.path.dirname(os.path.realpath(__file__))
    ctx = XlateContext(AppConfig(wdir + "/test.conf"), schema)
    sql, qmode, column_map, dont_care = DSL2SQL(json.loads(dsl), ctx)

    if e_qmode is not None:
        assert qmode == e_qmode

    if e_sql is not None:
        sql1 = normalize_sql_str(sql)
        sql2 = normalize_sql_str(e_sql)

        if sql1 != sql2:
            msg = "!!!!sql diff\n%s\nvs\n%s" % (sql1, sql2)
            print(msg, sql2.startswith(' '))
            assert False, msg

def test_agg1():
    dsl = '''
{
  "aggs": {
    "fagg": {
      "filter": {
        "bool": {
          "must": {
            "bool": {
              "should": [
                {
                  "query_string": {
                    "query": "isAttack:F"
                  }
                },
                {
                  "query_string": {
                    "query": "act:PASS AND isAttack:T"
                  }
                },
                {
                  "query_string": {
                    "query": "NOT (act:PASS) AND isAttack:T"
                  }
                }
              ]
            }
          },
          "filter": {
            "bool": {
              "must": [
                {
                  "range": {
                    "@timestamp": {
                      "from": 1514764800000,
                      "to": 1537920000000
                    }
                  }
                }
              ]
            }
          }
        }
      },
      "aggs": {
        "tagg": {
          "terms": {
            "field": "request",
            "size": 20,
            "order": {
              "sagg.sum": "desc"
            }
          },
          "aggs": {
            "sagg": {
              "stats": {
                "field": "cnt"
              }
            }
          }
        }
      }
    }
  },
  "size": 0
}'''

    sql = '''
select request AS col_1,
count(CASE WHEN 1 = 1 THEN cnt  END) AS col_2,
min(CASE WHEN 1 = 1 THEN cnt  END) AS col_3,
max(CASE WHEN 1 = 1 THEN cnt  END) AS col_4,
avg(CASE WHEN 1 = 1 THEN cnt  END) AS col_5,
sum(CASE WHEN 1 = 1 THEN cnt  END) AS col_6
from `mytable`
WHERE (isAttack = FALSE AND (isAttack IS NOT NULL) OR (act LIKE '%PASS%')
AND isAttack = TRUE AND (act IS NOT NULL) AND (isAttack IS NOT NULL) OR
NOT (act LIKE '%PASS%') AND isAttack = TRUE AND (act IS NOT NULL) AND
(isAttack IS NOT NULL)) AND `@timestamp` >= '2018-01-01 00:00:00' AND
`@timestamp` <= '2018-09-26 00:00:00' AND (`@timestamp` IS NOT NULL) AND
(request IS NOT NULL)
GROUP BY 1
ORDER BY 6 DESC
LIMIT 20'''
    dsl_2_sql_test(dsl, sql)

