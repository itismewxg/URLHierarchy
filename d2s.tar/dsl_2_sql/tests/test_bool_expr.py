import sys
import os
import json

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")

import xlate_condition as mycond
import xlate_sql_expr as myexpr
from xlate_config import XlateContext
from xlate_schema import Schema
from xlate_sql_expr_opt import optimize_expr

def parse_bool_dsl(dsl_str, schema=None, app_conf=None):
    if schema is None:
        schema = Schema("mytable", {})
    ctx = XlateContext(app_conf, schema)

    dsl = json.loads(dsl_str)
    res = mycond.analyze_block(dsl, ctx)
    res = optimize_expr(res)
    return myexpr.emit_expr(res, ctx, True)

def test_terms():
    dsl = '''{"terms" : {
                "user1": ["a", "b"],
                "user2": ["c", "d"]
           }}'''
    expect = "(user1 = 'a' OR user1 = 'b') AND (user2 = 'c' OR user2 = 'd')"
    assert parse_bool_dsl(dsl) == expect

def test_match_phrase():
    dsl = '''{
            "match_phrase" : {
                "msg": "this is a test"
             }
          }'''
    expect = "(msg LIKE '%this is a test%')"
    assert parse_bool_dsl(dsl) == expect

def test_querysting1():
    dsl = '''{
              "query_string": {
                "query": "tel_inferF: *DO?M*"
             }
          }'''
    expect = "(tel_inferF LIKE '%DO_M%')"
    assert parse_bool_dsl(dsl) == expect

def test_querysting2():
    dsl = '''{
              "query_string": {
                "query": "tel_inferF: *DO?M"
             }
          }'''
    expect = "(tel_inferF LIKE '%DO_M%')"
    assert parse_bool_dsl(dsl) == expect

def test_term():
    dsl = '''{
                "term" : { "user" : "a silly guy" }
             }'''

    expect = "user = 'a silly guy'"
    assert parse_bool_dsl(dsl) == expect

def test_must_1():
    dsl = r'''{"must" : {
                "term": { "user" : "kimchy" }
               }
             }'''
    expect = "user = 'kimchy'"
    assert parse_bool_dsl(dsl) == expect

def test_must_2():
    dsl = r'''{"must" : [
                {"term": {"user" : "david"}},
                {"term": {"hobby" : "boxing"}}
               ]
             }'''
    expect = "user = 'david' AND hobby = 'boxing'"
    assert parse_bool_dsl(dsl) == expect

def test_bool_1():
    dsl = '{"bool" : {}}'
    expect = '1 = 1'
    assert parse_bool_dsl(dsl) == expect

def test_null_1():
    dsl = '{"term" : {"colname": "null" }}'
    expect = '(colname IS NULL)'
    assert parse_bool_dsl(dsl) == expect

def test_exists():
    dsl = '{"exists" : {"field": "haha"}}'
    expect = '(haha IS NOT NULL)'
    assert parse_bool_dsl(dsl) == expect


# _exists_/_missing_ hanck (DA-617)
def test_exists_missing():
    dsl = '''
{
        "bool": {
          "should": [
            {
              "query_string": {
                "query": "(log_type:tel AND resourceLabel:Unevaluated) OR (log_type:tel AND NOT _exists_:resourceLabel)"
              }
            }
          ]
        }
}
'''

    expect = "(log_type LIKE '%tel%') AND (resourceLabel LIKE '%Unevaluated%') OR (log_type LIKE '%tel%') AND (resourceLabel IS NULL)"
    assert parse_bool_dsl(dsl) == expect
