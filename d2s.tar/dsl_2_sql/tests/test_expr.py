import sys
import os
import json
import time

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../../")
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../db_backend")

from xlate_sql_expr import *
from xlate_schema import Schema
from xlate_config import XlateContext
from xlate_sql_expr_opt import optimize_expr

def test_versatile_list():
    ctx = XlateContext(None, Schema("mytable", {}))

    opnd_list = [gen_keyword('epoch'),
                 gen_keyword('from'),
                 ExprOpndLiteral("lol"),
                 ExprOpndLiteral(12.3)]

    expr = gen_versatile_list(opnd_list)
    result = emit_expr(expr, ctx)

    assert result == "epoch from 'lol' 12.3"


def test_bool_opt1():
    # FALSE and what-ever-cond -> FALSE
    ctx = XlateContext(None, Schema("mytable", {}))

    term1 = gen_binary_expr(OPR_EQ, ExprOpndLiteral(1), ExprOpndLiteral(0))
    term2 = gen_binary_expr(OPR_EQ, ExprOpndLiteral("x"), ExprOpndLiteral('y'))
    expr = gen_binary_expr(OPR_AND, term1, term2)
    result = emit_expr(optimize_expr(expr), ctx)

    assert result == '1 = 0'


def test_bool_opt2():
    # TRUE and what-ever-cond -> what-ever-cond
    ctx = XlateContext(None, Schema("mytable", {}))

    term1 = gen_binary_expr(OPR_EQ, ExprOpndLiteral(1), ExprOpndLiteral(1))
    term2 = gen_binary_expr(OPR_EQ, ExprOpndLiteral("x"), ExprOpndLiteral('y'))
    expr = gen_binary_expr(OPR_AND, term1, term2)
    result = emit_expr(optimize_expr(expr), ctx)

    assert result == "'x' = 'y'"


def test_bool_opt3():
    # "not not expr" => expr
    ctx = XlateContext(None, Schema("mytable", {}))
    whatever_cond = gen_binary_expr(OPR_GT, ExprOpndLiteral('x'), ExprOpndLiteral('y'))
    to_opt = gen_unary_expr(OPR_NEG, gen_unary_expr(OPR_NEG, whatever_cond))
    opt_res = optimize_expr(to_opt)

    assert emit_expr(opt_res, ctx) == "'x' > 'y'"


def test_bool_opt4():
    # "TRUE or what-ever-cond" -> 1 == 1
    ctx = XlateContext(None, Schema("mytable", {}))

    term1 = gen_binary_expr(OPR_EQ, ExprOpndLiteral(1), ExprOpndLiteral(1))
    term2 = gen_binary_expr(OPR_EQ, ExprOpndLiteral("x"), ExprOpndLiteral('y'))
    expr = gen_binary_expr(OPR_OR, term1, term2)
    result = emit_expr(optimize_expr(expr), ctx)

    assert result == "1 = 1"


def test_bool_opt5():
    # "FALSE or what-ever-cond" -> what-ever-cond
    ctx = XlateContext(None, Schema("mytable", {}))

    term1 = gen_binary_expr(OPR_EQ, ExprOpndLiteral(2), ExprOpndLiteral(1))
    term2 = gen_binary_expr(OPR_EQ, ExprOpndLiteral("x"), ExprOpndLiteral('y'))
    expr = gen_binary_expr(OPR_OR, term1, term2)
    result = emit_expr(optimize_expr(expr), ctx)

    assert result == "'x' = 'y'"


def test_bool_opt6():
    # "(1 == 0) or what-ever-cond" -> what-ever-cond
    ctx = XlateContext(None, Schema("mytable", {}))

    term1 = gen_binary_expr(OPR_EQ, ExprOpndLiteral(1), ExprOpndLiteral(1))
    term2 = gen_binary_expr(OPR_EQ, ExprOpndLiteral("x"), ExprOpndLiteral('y'))
    expr = gen_binary_expr(OPR_OR, term1, term2)
    result = emit_expr(optimize_expr(expr), ctx)

    assert result == "1 = 1"
