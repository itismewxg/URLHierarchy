import sys
import os
import json

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")

from xlate_translate import DSL2SQL
import xlate_condition as mycond
import xlate_sql_expr as myexpr
from xlate_config import XlateContext, AppConfig
from xlate_schema import Schema

def normalize_sql_str(sql_stmt):
    tokens = sql_stmt.replace('\n', ' ').split(' ')
    tokens = [x for x in tokens if x != '']
    return ' '.join(tokens)

def dsl_2_sql_test(dsl, expect_failed, e_sql=None):
    schema = Schema('mytable', {'@timestamp': 'date', 'isAttack': 'bool' })
    wdir = os.path.dirname(os.path.realpath(__file__))
    ctx = XlateContext(AppConfig(wdir + "/test.conf"), schema)
    try:
        sql, qmode, column_map, dont_care = DSL2SQL(json.loads(dsl), ctx)
    except Exception as e:
        if expect_failed:
            return
        assert False, "wtf"

    assert qmode == 'listView'
    if e_sql is not None:
        sql1 = normalize_sql_str(sql)
        sql2 = normalize_sql_str(e_sql)

        if sql1 != sql2:
            msg = "!!!!sql diff\n%s\nvs\n%s" % (sql1, sql2)
            print(msg, sql2.startswith(' '))
            assert False, msg

def test_non_aggr1():
    # if neither condition nor limit is specified, ...
    dsl = "{}"
    dsl_2_sql_test(dsl, True)

def test_non_aggr2():
    # if limit is not specified, ...
    dsl = '''{
          "filtered": {
            "query": {
              "query_string": {
                "query": "wtf:F OR wtf:PASS"
              }
            }
          }
    }'''

    dsl_2_sql_test(dsl, True)

def test_non_aggr3():

    dsl = '''{
          "filtered": {
            "query": {
              "query_string": {
                "query": "wtf:F OR wtf:PASS"
              }
            }
          },
          "size": 20
      }'''

    expect_sql = "SELECT TO_JSON_STRING(t) FROM `mytable` AS t WHERE ((wtf LIKE '%F%') OR (wtf LIKE '%PASS%')) AND (wtf IS NOT NULL) LIMIT 20"
    dsl_2_sql_test(dsl, False, expect_sql)
