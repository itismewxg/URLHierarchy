import sys
import os
import json
import time
import copy

sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../")
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../../")
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../db_backend")

from xlate_sql_expr import *
from xlate_schema import Schema
from xlate_config import XlateContext
from xlate_sql_expr_opt import optimize_expr
from xlate_null_analysis import insert_column_neq_null_condition

def test_null_insert_1():
    # "x > 5 && y == 3 or z > 4 and x < 10" ->
    # (x != null) and (x > 5 && y == 3 && y != null) or z > 4 and x < 10 & z != null)
    x_col = ExprOpndColumnRef("x")
    y_col = ExprOpndColumnRef("y")
    z_col = ExprOpndColumnRef("z")

    # generate the expr
    e1 = gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(5))
    e2 = gen_binary_expr(OPR_EQ, y_col, ExprOpndLiteral(3))
    e3 = gen_binary_expr(OPR_GT, z_col, ExprOpndLiteral(4))
    e4 = gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(10))

    expr = gen_binary_expr(OPR_OR, \
            gen_binary_expr(OPR_AND, e1, e2), \
            gen_binary_expr(OPR_AND, e3, e4))

    ctx = XlateContext(None, Schema("mytable", {}))
    insert_column_neq_null_condition(expr, ctx)
    result = emit_expr(expr, ctx)

    expect = "(x > 5 AND y = 3 AND (y IS NOT NULL) OR z > 4 AND x > 10 AND (z IS NOT NULL)) AND (x IS NOT NULL)"

    assert result == expect

def test_null_insert_2():
    # "x > 5 && y == 3 && (y != null) =>
    # (x > 5 && y == 3 && (y != null) && x != null
    ctx = XlateContext(None, Schema("mytable", {}))

    x_col = ExprOpndColumnRef("x")
    y_col = ExprOpndColumnRef("y")

    x_gt_5 = gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(5))
    y_eq_3 = gen_binary_expr(OPR_EQ, y_col, ExprOpndLiteral(3))

    y_ne_null = gen_column_ne_null('y', ctx)

    opnds = [x_gt_5, y_eq_3, y_ne_null]
    expr = gen_nary_and_expr(opnds)
    insert_column_neq_null_condition(expr, ctx)

    result = emit_expr(expr, ctx)
    expect = "x > 5 AND y = 3 AND (y IS NOT NULL) AND (x IS NOT NULL)"

    assert result == expect

def test_null_insert_3():
    # "x > 5 && y == 3 && (y != null), group by x, y, z =>
    # (x > 5 && y == 3 && (y != null) && x != null && z != null
    ctx = XlateContext(None, Schema("mytable", {}))
    ctx.set_non_null_columns(['x', 'y', 'z'])

    x_col = ExprOpndColumnRef("x")
    y_col = ExprOpndColumnRef("y")

    x_gt_5 = gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(5))
    y_eq_3 = gen_binary_expr(OPR_EQ, y_col, ExprOpndLiteral(3))

    y_ne_null = gen_column_ne_null('y', ctx)

    opnds = [x_gt_5, y_eq_3, y_ne_null]
    expr = gen_nary_and_expr(opnds)
    insert_column_neq_null_condition(expr, ctx)

    result = emit_expr(expr, ctx)
    expect = "x > 5 AND y = 3 AND (y IS NOT NULL) AND (x IS NOT NULL) AND (z IS NOT NULL)"

    assert result == expect

def test_null_insert_4():
    # "x > 5 || y == 3 && (y != null), group by ... => ...
    ctx = XlateContext(None, Schema("mytable", {}))

    x_col = ExprOpndColumnRef("x")
    y_col = ExprOpndColumnRef("y")

    x_gt_5 = gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(5))

    y_eq_3 = gen_binary_expr(OPR_EQ, y_col, ExprOpndLiteral(3))
    y_ne_null = gen_column_ne_null('y', ctx)

    expr = gen_binary_expr(OPR_OR, x_gt_5, gen_binary_expr(OPR_AND, y_eq_3, y_ne_null))
    expr_copy2 = copy.deepcopy(expr)
    expr_copy3 = copy.deepcopy(expr)

    insert_column_neq_null_condition(expr, ctx)
    result = emit_expr(expr, ctx)
    expect = "x > 5 AND (x IS NOT NULL) OR y = 3 AND (y IS NOT NULL)"
    assert result == expect

    # group by x
    ctx.set_non_null_columns(['x'])
    insert_column_neq_null_condition(expr_copy2, ctx)
    result2 = emit_expr(expr_copy2, ctx)
    expect2 = "(x > 5 OR y = 3 AND (y IS NOT NULL)) AND (x IS NOT NULL)"
    assert result2 == expect2

    # group by x
    ctx.set_non_null_columns(['x', 'm', 'n'])
    insert_column_neq_null_condition(expr_copy3, ctx)
    result3 = emit_expr(expr_copy3, ctx)
    expect3 = "(x > 5 OR y = 3 AND (y IS NOT NULL)) AND (m IS NOT NULL) AND (n IS NOT NULL) AND (x IS NOT NULL)"
    assert result3 == expect3


def test_null_insert_5():
    # (x > z || y == 5) && x > 3 => (x > z && z != null || y == 3 && y != null) && x != null
    ctx = XlateContext(None, Schema("mytable", {}))

    x_col = ExprOpndColumnRef("x")
    y_col = ExprOpndColumnRef("y")
    z_col = ExprOpndColumnRef("z")

    x_gt_z = gen_binary_expr(OPR_GT, x_col, z_col)
    y_eq_3 = gen_binary_expr(OPR_EQ, y_col, ExprOpndLiteral(5))
    or1 = gen_binary_expr(OPR_OR, x_gt_z, y_eq_3)

    x_gt_3 =  gen_binary_expr(OPR_GT, x_col, ExprOpndLiteral(3))
    expr = gen_binary_expr(OPR_AND, or1, x_gt_3)

    insert_column_neq_null_condition(expr, ctx)
    result = emit_expr(expr, ctx)

    # Ideally we should yield the result as indicated by `expect_good`,
    # The resulting transformation of our current implementation is `expected_bad`.
    # It is correct but defective in the sense the `(x IS NOT NULL)` in the
    # `(x > z AND (x IS NOT NULL)...` is completely unnecessary

    #expect_good = "(x > z AND (z IS NOT NULL) OR y = 5 AND (y IS NOT NULL)) AND (x IS NOT NULL)"
    expect_bad = "(x > z AND (x IS NOT NULL) AND (z IS NOT NULL) OR y = 5 AND (y IS NOT NULL)) AND x > 3 AND (x IS NOT NULL)"
    assert result == expect_bad
