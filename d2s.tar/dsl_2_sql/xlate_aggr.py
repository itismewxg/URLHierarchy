#pylint: disable=fixme,invalid-name,superfluous-parens,bare-except
#pylint: disable=missing-docstring,too-few-public-methods
#pylint: disable=too-many-instance-attributes,consider-using-enumerate
#pylint: disable=too-many-locals,protected-access,relative-import
#pylint: disable=line-too-long,inconsistent-return-statements

import xlate_sql_expr as myexpr
from xlate_utils import not_supported, dsl_failed_to_parse, dsl_assert_key, \
    get_single_kv_pair
from xlate_condition import analyze_block
from xlate_sql_expr_transform import expr_promote_to_nary, factor_out_common_AND_term
from xlate_sql_element import Column
from xlate_sql_expr_opt import optimize_expr
from xlate_null_analysis import insert_column_neq_null_condition

def analyze_datehistogram(dsl_blk, conf):
    # TODO: 1. need to know if the field in question is in unit of ms or s
    #       2. handle column in string type
    #       3. handle 'format' key
    #       4. the list goes on ...
    #
    # https://www.elastic.co/guide/en/elasticsearch/reference/current/common-options.html#time-units
    dsl_assert_key(dsl_blk, ['interval', 'field'])

    interval = dsl_blk['interval']
    column = dsl_blk['field']

    lookup_tab = {'minute': 60, '1m': 60, 'second': 1, '1s': 1,
                  'hour': 3600, '1h': 3600}

    seconds = lookup_tab.get(interval)
    if seconds is None:
        unit_scale = {'m': 60, 's': 1, 'h': 3600, 'd': 24*3600}
        try:
            seconds = int(interval[:-1]) * unit_scale.get(interval[-1])
        except:
            dsl_failed_to_parse(dsl_blk)

    # emit an expression depict the expression like this
    #  (cast(column / 3600000 as long) * 3600) as column_alias

    # TODO: this part is backend-database/application specific, we currently
    # hard-coded for Google BigQuery
    db = conf.get_backend_db()

    if conf.time_in_millis():
        col = db.get_ts_in_millis(column)
        time_scale = 1000
    else:
        col = db.get_ts_in_seconds(column)
        time_scale = 1

    div = myexpr.gen_binary_expr(myexpr.OPR_DIV,
                                 col,
                                 myexpr.ExprOpndLiteral(seconds * time_scale))

    long_ty = db.cvt_to_native_type('long')
    cast = myexpr.gen_call_expr("sql_cast",
                                [div, myexpr.ExprOpndLiteral(long_ty)])
    return myexpr.gen_binary_expr(myexpr.OPR_MUL, cast,
                                  myexpr.ExprOpndLiteral(seconds * time_scale))

class Aggregation(object):
    TY_CONTAINER = 1
    TY_BUCKET = 2
    TY_METRIC = 3
    TY_UNKNOWN = 4

    QM_HISTO_SCOUNT_VIEW = "histoSCountView"
    QM_HISTO_COUNT_VIEW = "histoCountView"
    QM_TOPN_COUNT_VIEW = "topNCountView"
    QM_TOPN_SCOUNT_VIEW = "topNSCountView"

    NESTING_SPLITER = ':'

    def __init__(self, name, dsl, ctx, enclosing_aggr, nesting_level=0):
        #pylint: disable=too-many-arguments
        self._name = name
        self._dsl = dsl
        self._ctx = ctx
        self._enclosing_aggr = enclosing_aggr
        self._nesting_level = nesting_level
        self._ty = self.TY_UNKNOWN
        self._inner_aggr_grp = None
        self._groupbys = []
        self._metric_exprs_dict = {}
        self._condition_expr = None
        self._sql_limit = None
        self._define_bucket = False
        self._query_mode = None # one of QM_XXXX
        self._order_asc = True
        self._order_by_column = None # full path e.g. fagg:tagg:buckets:sagg:sum


    def get_query_mode(self):
        assert self._enclosing_aggr is None
        return self._query_mode


    def set_query_mode(self, mode):
        assert self._enclosing_aggr is None
        self._query_mode = mode


    def get_sql_limit(self):
        if self._sql_limit is not None:
            return self._sql_limit

        if self._inner_aggr_grp is not None:
            return self._inner_aggr_grp.get_sql_limit()

    def get_outermost_aggregation(self):
        outer = self
        while True:
            if outer._enclosing_aggr is None:
                return outer
            outer = outer._enclosing_aggr


    def order_asc(self):
        return self._order_asc


    def get_order_by_column(self):
        if self._order_by_column is not None:
            return self._order_by_column, self._order_asc

        if self._inner_aggr_grp is not None:
            return self._inner_aggr_grp.get_order_by_column()

        return None, None


    def _analyze_datehistogram(self, dsl_blk):
        self.get_outermost_aggregation().set_query_mode(self.QM_HISTO_COUNT_VIEW)
        col_expr = analyze_datehistogram(dsl_blk, self._ctx.get_conf())
        col = Column(col_expr, orderby=True, orderby_asc=True)
        self._groupbys.append(col)


    def _analyze_terms(self, dsl_blk):
        """ hint: terms is corresponding to topn, this is an example:
            {
                "aggs": {
                    "rslt" : {
                        "terms" : {
                            "field": "abc",
                            "size": 20
                        }
                    }
                }
            }

        """
        self.get_outermost_aggregation().set_query_mode(self.QM_TOPN_COUNT_VIEW)
        self._order_asc = False
        for k in dsl_blk:
            v = dsl_blk[k]
            if k == 'field':
                col_ref = myexpr.ExprOpndColumnRef(v)
                col_expr = myexpr.gen_degenerate_expr(col_ref)
                self._groupbys.append(Column(col_expr))

                doc_count_expr = myexpr.gen_call_expr('doc_count',
                                                      [myexpr.ExprOpndLiteral(1)])
                doc_count_col = Column(doc_count_expr, orderby=True,
                                       orderby_asc=False)
                self._metric_exprs_dict['doc_count'] = doc_count_col

                continue

            if k == 'size':
                self._sql_limit = v
                continue

            if k == 'order':
                order_col, order_asc = get_single_kv_pair(v)
                if order_asc.lower() in ['asc', 'desc']:
                    self._order_asc = True if order_asc.lower() == 'asc' else False
                else:
                    dsl_failed_to_parse({"terms": dsl_blk})

                # deal with intrinsic sort
                #https://www.elastic.co/guide/en/elasticsearch/guide/current/_intrinsic_sorts.html
                if order_col == '_count':
                    continue

                if order_col in ['_term', '_key']:
                    # TODO: should we classify these cases in WTF category?
                    continue

                # order by particular column
                prefix = self._get_nesting_path_str()
                self._order_by_column = prefix + self.NESTING_SPLITER + \
                    order_col.replace('.', self.NESTING_SPLITER)
                continue

            not_supported(k, 'terms')


    def analyze(self):
        # make sure the nesting relationship is established properly
        assert self._enclosing_aggr is None or \
               self._enclosing_aggr._inner_aggr_grp == self

        inner_aggs = []

        for ki in self._dsl:
            val = self._dsl[ki]
            if ki in ['filter', 'query']:
                self._analyze_condition(val)
                continue

            if ki == 'date_histogram':
                self._define_bucket = True
                self._analyze_datehistogram(val)
                continue

            if ki == 'terms':
                self._define_bucket = True
                self._analyze_terms(val)
                continue

            if ki == 'aggs':
                # NOTE: nesting aggreagation must be processed after all other
                #  constructs at the same level are procssed.
                #
                inner_aggs.append(val)
                continue

            if ki == 'stats':
                self._analyze_stats(val)
                continue

        for iai in inner_aggs:
            self._analyze_inner_aggs(iai)


    def _analyze_inner_aggs(self, dsl_blk):
        if self._inner_aggr_grp is not None:
            raise Exception("multiple inner aggregation blocks")

        name, content = get_single_kv_pair(dsl_blk)
        self._inner_aggr_grp = Aggregation(name, content, self._ctx, self,
                                           self._nesting_level + 1)
        self._inner_aggr_grp.analyze()

    def _analyze_condition(self, filter_dsl):
        self._condition_expr = analyze_block(filter_dsl, self._ctx)


    def get_condition_expr(self):
        return self._condition_expr


    def set_condition_expr(self, expr):
        self._condition_expr = expr


    def _analyze_stats(self, dsl_blk):
        # find the enclosing aggregation having non-null query mode
        outermost_aggr = self.get_outermost_aggregation()
        outermost_qmode = outermost_aggr.get_query_mode()

        if outermost_qmode == self.QM_HISTO_COUNT_VIEW:
            outermost_aggr.set_query_mode(self.QM_HISTO_SCOUNT_VIEW)
        elif outermost_qmode == self.QM_TOPN_COUNT_VIEW:
            outermost_aggr.set_query_mode(self.QM_TOPN_SCOUNT_VIEW)
        else:
            raise Exception("query mode is not set properly")

        k, col_name = get_single_kv_pair(dsl_blk)
        if k != 'field':
            dsl_failed_to_parse({'stats': dsl_blk})

        col_ref = myexpr.ExprOpndColumnRef(col_name)
        count_col = None
        explicit_orderby = False

        order_by_col, order_by_asc = outermost_aggr.get_order_by_column()
        nesting_str = self._get_nesting_path_str()

        for aggr_func in ['count', 'min', 'max', 'avg', 'sum']:
            col_expr = myexpr.gen_call_expr(aggr_func, [col_ref])
            col = Column(col_expr)
            self._metric_exprs_dict[aggr_func] = col
            if aggr_func == 'count':
                count_col = col

            col_nesting_str = nesting_str + self.NESTING_SPLITER + aggr_func
            if col_nesting_str == order_by_col:
                col.orderby = order_by_asc
                explicit_orderby = True

        # if oder-by is not explictly specified, then order the result by
        # doc-count by default
        if not explicit_orderby:
            count_col.orderby = True
            count_col.orderby_asc = False


    def get_groupbys(self):
        if not self._groupbys:
            if self._inner_aggr_grp is not None:
                return self._inner_aggr_grp.get_groupbys()
        else:
            return self._groupbys


    def _get_inner_most_aggr(self):
        inner = self
        while inner._inner_aggr_grp is not None:
            inner = inner._inner_aggr_grp
        return inner


    def _get_nesting_path_str(self):
        '''return string depicting the nesting level of current aggregation
         e.g. fagg:tagg:buckets:sagg:sum'''
        name_path = []
        _iter = self
        while _iter is not None:
            if _iter._define_bucket:
                name_path.append("buckets")
            name_path.append(_iter._name)
            _iter = _iter._enclosing_aggr
        return self.NESTING_SPLITER.join(reversed(name_path))


    def _rematerialize_metric(self, col_info):
        # find the aggr corresponding to the DSL-block depicting the bucket
        leaf_aggr = self._get_inner_most_aggr()
        dsl_name_prefix = leaf_aggr._get_nesting_path_str()
        col_dsl_fmt = dsl_name_prefix + ":%(metric)s"

        # aggr corresponding to the DSL-block depicting the metric
        metric_cols = []

        metric_name_expr_dict = leaf_aggr._metric_exprs_dict
        if not metric_name_expr_dict:
            # if metric is not specified, use doc-count
            doc_cnt = myexpr.gen_call_expr('doc_count', [myexpr.ExprOpndLiteral(1)])
            metric_name_expr_dict = {leaf_aggr._name: Column(doc_cnt)}

        for metric_iter in metric_name_expr_dict:
            metric_col = metric_name_expr_dict[metric_iter]
            metric_cols.append(metric_col)

            # step 1: populate the column with name and index
            col_name = col_info.gen_col_name()
            metric_col.name = col_name
            metric_col.index = col_info.get_current_col_idx()

            # step 2: generate the sql clause for this metric
            aggr_func = metric_col.expr
            aggr_func_name = aggr_func.get_opnd0().get_literal().lower()

            col_dsl = col_dsl_fmt % {'metric': aggr_func_name}
            col_info.set_col_dsl_map(col_name, col_dsl)

            # convert elastic-search's aggregation to SQL aggregation
            sql_aggr_name = aggr_func_name
            if sql_aggr_name == 'doc_count':
                sql_aggr_name = 'SUM'

            if self._condition_expr is None:
                col_str = '%s(%s) AS %s' % (sql_aggr_name, \
                        myexpr.emit_opnd(aggr_func.get_opnd1(), \
                                         myexpr.lower_than_least_precedence, \
                                         self._ctx), \
                        col_name)
                metric_col.emit_string = col_str
                continue

            case_when = ("%(agg_func)s(CASE WHEN %(cond)s THEN %(aggr_expr)s "
                         " END) AS %(col_alias)s") % {
                             'agg_func': sql_aggr_name,
                             'cond': myexpr.emit_expr(self._condition_expr,
                                                      self._ctx),
                             'aggr_expr': myexpr.emit_opnd(aggr_func.get_opnd1(), \
                                myexpr.lower_than_least_precedence, self._ctx),
                             'col_alias': col_name}
            metric_col.emit_string = case_when

        return metric_cols


    def dump(self):
        print('\naggregation ' + self._name, "type ", self._ty)
        print ("condition")
        if self._condition_expr is not None:
            print(myexpr.emit_expr(self._condition_expr, self._ctx))
        else:
            print("None")

        print("groubys")
        gb = self.get_groupbys()
        for gbi in gb:
            print(myexpr.emit_expr(gbi.expr, self._ctx))


class SQLColumnInfo(object):
    def __init__(self):
        self._col_idx = 0
        self._col_dsl_map = {}

    def gen_col_name(self):
        self._col_idx += 1
        return "col_%d" % self._col_idx

    def get_current_col_idx(self):
        return self._col_idx

    def set_col_dsl_map(self, col, dsl):
        self._col_dsl_map[col] = dsl

    def get_col_dsl_map(self):
        return self._col_dsl_map


class AggrGroup(object):
    def __init__(self, dsl, xlate_ctx):
        assert 'aggs' in dsl
        self._dsl = dsl
        self._size = None
        self._sub_aggrs = {}
        self._common_condition = None
        self._optimized = False
        self._xlate_ctx = xlate_ctx
        self._analyze()


    def optimize(self):
        if self._optimized:
            return
        self._factor_out_common_AND_terms()
        self._optimized = True
        if self._common_condition is not None and \
           self._xlate_ctx.get_conf().enable_expr_optimization():
            self._common_condition = optimize_expr(self._common_condition)

    def _analyze_aggs(self):
        dsl = self._dsl['aggs']
        keys = dsl.keys()

        for ki in keys:
            val = dsl[ki]

            if ki == 'size':
                self._size = val
                continue

            #FIXME: I'm not aware of keywords other than 'size'
            self._sub_aggrs[ki] = Aggregation(ki, val, self._xlate_ctx, None)
            self._sub_aggrs[ki].analyze()

    def _analyze(self):
        for key in self._dsl:
            if key == 'aggs':
                self._analyze_aggs()
                continue

            if key == "query":
                cond = analyze_block(self._dsl[key], self._xlate_ctx)
                self._add_common_condition(cond)
                continue

            #TODO: handle other keys

    def getNestingAggrCnt(self):
        return len(self._sub_aggrs)


    def getSingleNestingAggr(self):
        if self.getNestingAggrCnt() == 1:
            for k in self._sub_aggrs:
                return self._sub_aggrs[k]


    def _add_common_condition(self, expr):
        if self._common_condition is None:
            self._common_condition = expr
            return

        self._common_condition = \
            myexpr.gen_nary_and_expr([self._common_condition, expr])


    def _factor_out_common_AND_terms(self):
        aggr_names = list(self._sub_aggrs.keys())

        # if there is only one aggregation, move the aggregation condition
        # to where-clause
        if len(aggr_names) == 1:
            name = aggr_names[0]
            expr = self._sub_aggrs[name].get_condition_expr()
            true_expr = myexpr.get_true_expr()
            if expr != true_expr and expr is not None:
                self._add_common_condition(expr)
                self._sub_aggrs[name].set_condition_expr(true_expr)
            return

        aggr_cond = [None] * len(aggr_names)

        for idx in range(len(aggr_names)):
            name = aggr_names[idx]
            expr = self._sub_aggrs[name].get_condition_expr()
            aggr_cond[idx] = expr

            expr_promote_to_nary(expr)

        result = factor_out_common_AND_term(aggr_cond)
        if result is not None:
            for idx in range(len(aggr_names)):
                name = aggr_names[idx]
                self._sub_aggrs[name].set_condition_expr(result[idx])
            self._add_common_condition(result[-1])


    @staticmethod
    def _compare_groupby(gy1, gy2):
        l1 = len(gy1)
        l2 = len(gy2)

        if l1 != l2:
            return False

        for gy_iter1 in gy1:
            eq = False
            for gy_iter2 in gy2:
                if gy_iter1 == gy_iter2:
                    eq = True
                    break
            if not eq:
                return False

        for gy_iter1 in gy2:
            eq = False
            for gy_iter2 in gy1:
                if gy_iter1 == gy_iter2:
                    eq = True
                    break
            if not eq:
                return False

        return True

    def _are_aggs_homogeneous(self):
        """
        there will be multiple aggregation in a single block, make sure there
        share the same groupby and orderbys. We would otherwise not able to
        emit a single SQL for all aggregations
        """
        if len(self._sub_aggrs) <= 1:
            return True

        # all aggregations share the same group-by
        groupbys = [self._sub_aggrs[x].get_groupbys() for x in self._sub_aggrs]
        gy = groupbys[0]
        for gy_iter in groupbys:
            if not self._compare_groupby(gy, gy_iter):
                return False

        # all aggregations same the same order-by
        orderbys = [self._sub_aggrs[x].get_order_by_column() for x in self._sub_aggrs]
        ob = orderbys[0]
        for ob_iter in orderbys:
            if ob != ob_iter:
                return False

        return True

    def _rematerialize_groupby(self, col_info):
        assert self._are_aggs_homogeneous()

        groupbys = None
        for x in self._sub_aggrs:
            groupbys = self._sub_aggrs[x].get_groupbys()
            break

        for gy_iter in groupbys:
            gy_iter.name = col_info.gen_col_name()
            col_expr_str = myexpr.emit_opnd(gy_iter.expr,
                                            myexpr.lower_than_least_precedence,
                                            self._xlate_ctx)
            gy_iter.emit_string = "%s AS %s" % (col_expr_str, gy_iter.name)
            gy_iter.index = col_info.get_current_col_idx()

            col_info.set_col_dsl_map(gy_iter.name, "key")

        return groupbys


    def _rematerialize_metric(self, col_info):
        metric_columns = []
        for ai in self._sub_aggrs:
            metrics = self._sub_aggrs[ai]._rematerialize_metric(col_info)
            metric_columns.extend(metrics)

        return metric_columns


    def _get_a_aggr(self):
        for ai in self._sub_aggrs:
            return self._sub_aggrs[ai]


    def emit_sql(self):
        self.optimize()

        col_info = SQLColumnInfo()

        # get the columns which will be groupby-ed
        groupby_cols = self._rematerialize_groupby(col_info)

        # get the columns corresponding to 'metrics'
        metric_cols = self._rematerialize_metric(col_info)

        # collect all 'orderby' columns
        orderby_cols = []
        for gi in groupby_cols:
            if gi.orderby is not None:
                orderby_cols.append(gi)
        for mi in metric_cols:
            if mi.orderby is not None:
                orderby_cols.append(mi)

        groupby_col_clause = ', '.join([x.emit_string for x in groupby_cols])
        metric_col_clause = ',\n'.join([x.emit_string for x in metric_cols])
        groupby_clause = ', '.join([
            self._xlate_ctx.get_conf().get_backend_db().emit_column_representation(x) for x in groupby_cols])
        orderby_clause = ', '.join(["%s %s" % \
            (self._xlate_ctx.get_conf().get_backend_db().emit_column_representation(x),
             "ASC" if x.orderby_asc else "DESC") \
            for x in orderby_cols])

        where_clause = ""
        if self._common_condition is not None:
            gb_col_names = set()
            for gb_iter in groupby_cols:
                gb_col_names = gb_col_names.union(myexpr.extract_column_names(gb_iter.expr))

            self._xlate_ctx.set_non_null_columns(list(gb_col_names))
            insert_column_neq_null_condition(self._common_condition, self._xlate_ctx)
            where_clause = \
                "WHERE %s\n" % (myexpr.emit_expr(self._common_condition,
                                                 self._xlate_ctx))

        limit_n = self._get_a_aggr().get_sql_limit()
        limit_clause = "" if limit_n is None else "\nLIMIT %d" % limit_n

        tab_name = self._xlate_ctx.get_current_table()
        tab_name = self._xlate_ctx.get_conf().get_backend_db().emit_table_name(tab_name)

        sql_stmt = ("select %(groupby_col_clause)s,\n"
                    "%(metric_col_clause)s \n"
                    "from %(table)s \n"
                    "%(where)s"
                    "GROUP BY %(groupby_list)s \n"
                    "ORDER BY %(orderby_list)s"
                    "%(limit)s") % {
                        "groupby_col_clause": groupby_col_clause,
                        "metric_col_clause": metric_col_clause,
                        "table": tab_name,
                        "where": where_clause,
                        "groupby_list": groupby_clause,
                        "orderby_list": orderby_clause,
                        "limit": limit_clause
                    }
        return sql_stmt, self._get_a_aggr().get_query_mode(), \
               col_info.get_col_dsl_map(), None


    def dump(self):
        for ai in self._sub_aggrs:
            self._sub_aggrs[ai].dump()

        if self._common_condition is not None:
            print("\ncommon condition:")
            print(myexpr.emit_expr(self._common_condition, self._xlate_ctx))
