#pylint: disable=missing-docstring,invalid-name,fixme
#pylint: disable=too-many-branches,global-statement,relative-import

import threading
import json
import datetime

# NOTE: following ugly, circuitous code is to workaround the annoying bug
# of relative-import in python 3.5+. As of I write this comment, I have no
# idea how to fix it right
# ImportError: attempted relative import with no known parent package
#
#from ..myluqum.parser import parser
#from ..myluqum.elasticsearch import ElasticsearchQueryBuilder
#
import os
import sys
parent_dir = os.path.dirname(os.path.realpath(__file__)) + "/../.."
if parent_dir not in sys.path:
    sys.path.insert(1, parent_dir)
from luqum.parser import parser
from luqum.elasticsearch import ElasticsearchQueryBuilder

import xlate_sql_expr as myexpr
from xlate_utils import get_single_kv_pair, not_supported, dsl_failed_to_parse

compound_dispatch = None
leaf_dispatch = None
compound_keys = None
leaf_keys = None

ignore_attribute = {
    "fquery": ["_cache"]
}

# Parser is not thread-safe, neither is its dependent PLY lib. To workaround
# this problem, we have to disable concurrent parsing for now.
#
paser_lock = threading.RLock()

###########################################################################
#
#           Helper routines
#
###########################################################################
#


def gen_nary_and_expr_wrap(opnd_list):
    opnd_num = len(opnd_list)
    if opnd_num == 1:
        return opnd_list[0]

    if opnd_num > 1:
        return myexpr.gen_nary_and_expr(opnd_list)

    #opnd_num could be 0, e.g when parsing the DSL {'bool':{}}
    return myexpr.get_true_expr()


###########################################################################
#
#           leaf expr handler
#
###########################################################################
#
def analyze_query_string(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'query_string'

    es_builder = ElasticsearchQueryBuilder()
    opr, q_str = get_single_kv_pair(dsl_val)
    if opr != 'query':
        not_supported(opr, 'query_string')

    # catch some common, trivial cases
    if q_str == '*':
        return myexpr.get_true_expr()

    # convert the query string back the ES DSL
    tree = None
    with paser_lock:
        tree = parser.parse(q_str)

    # HINT: ElasticsearchQueryBuilder.__call__() is invoked
    query = es_builder(tree)
    return _analyze_block(query, xlate_ctx)


def _gen_match_expr(column, match_val, xlate_ctx, process_wildcard=False):
    # some special scenarios need to be translated to boolean comparison. So messy!
    if xlate_ctx.get_schema().is_boolean_type(column):
        val_str = str(match_val).lower()
        if val_str in ['false', 'f', '0']:
            bool_val = False
        elif match_val.lower() in ['true', 't', '1']:
            bool_val = True
        else:
            exp_msg = "unknown boolean value: " + val_str
            raise Exception(exp_msg)

        return myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                      myexpr.ExprOpndColumnRef(column),
                                      myexpr.ExprOpndLiteral(bool_val))

    if xlate_ctx.get_schema().is_int_type(column):
        return myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                      myexpr.ExprOpndColumnRef(column),
                                      myexpr.ExprOpndLiteral(int(match_val)))

    if xlate_ctx.get_schema().is_float_type(column):
        return myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                      myexpr.ExprOpndColumnRef(column),
                                      myexpr.ExprOpndLiteral(float(match_val)))
    if process_wildcard:
        if match_val.startswith('*'):
            match_val = match_val[1:]
        if match_val.endswith('*'):
            match_val = match_val[:-1]
        match_val = match_val.replace('*', '%').replace('?', '_')

    return myexpr.gen_binary_expr(myexpr.OPR_MATCH,
                                  myexpr.ExprOpndColumnRef(column),
                                  myexpr.ExprOpndLiteral(match_val))


def _hack__exists_(xlate_ctx, col_name):
    null_val = xlate_ctx.get_null_value()
    res = myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                 myexpr.ExprOpndColumnRef(col_name),
                                 myexpr.ExprOpndLiteral(null_val))
    return myexpr.gen_unary_expr(myexpr.OPR_NEG, res)


def _hack__missing_(xlate_ctx, col_name):
    null_val = xlate_ctx.get_null_value()
    return myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                  myexpr.ExprOpndColumnRef(col_name),
                                  myexpr.ExprOpndLiteral(null_val))

# https://www.elastic.co/guide/en/elasticsearch/reference/2.4/query-dsl-match-query.html#query-dsl-match-query
def analyze_match(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'match'
    col_name, match_val = get_single_kv_pair(dsl_val)
    and_opr = False

    include_wildcard = False
    if isinstance(match_val, str):
        tokens = match_val.split(' ')
    elif isinstance(match_val, dict):
        # hack: luqum does not handle _missing_ and _exists_ right. We workaround
        # the problem by hacking here
        if col_name == '_exists_':
            return _hack__exists_(xlate_ctx, match_val['query'])

        if col_name == '_missing_':
            return _hack__missing_(xlate_ctx, match_val['query'])

        # for the case like this
        # { "match" : {
        #    "message" : {
        #        "query" : "to be or not to be",
        #        "operator" : "and",
        #        "zero_terms_query": "all"
        #    }
        # }
        opr = match_val.get('operator', 'or')
        if opr not in ('and', 'or'):
            dsl_failed_to_parse(dsl_val)
        elif opr == 'and':
            and_opr = True
        tokens = match_val.get('query', '').split(' ')

        if 'shape_wildcard' in match_val:
            # our own luqum version does not handle wildcard, instead
            # it just adds 'shape_wildcard', and return the match pattern
            # back.
            include_wildcard = True

        # NOTE: 'zero_terms_query' can be ignored for our case

    opnds = [_gen_match_expr(col_name, token, xlate_ctx, \
                process_wildcard=include_wildcard) for token in tokens]
    if and_opr:
        return myexpr.gen_nary_and_expr(opnds)

    return myexpr.gen_nary_or_expr(opnds)


# https://www.elastic.co/guide/en/elasticsearch/reference/2.4/query-dsl-match-query.html#query-dsl-match-query-phrase
def analyze_match_phrase(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'match_phrase'
    col_name, phrase_blk = get_single_kv_pair(dsl_val)

    phrase = None
    if isinstance(phrase_blk, str):
        phrase = phrase_blk
    elif isinstance(phrase_blk, dict):
        for opr in phrase_blk:
            if opr != 'query':
                not_supported(opr, 'match_phrase')

        phrase = phrase_blk.get('query')

    if phrase is None:
        dsl_failed_to_parse(dsl_val)

    be = _gen_match_expr(col_name, phrase, xlate_ctx)
    if be is not None:
        return be

    dsl_failed_to_parse(dsl_val)


def analyze_exists(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'exists'

    col = dsl_val.get('field')
    if col is None:
        dsl_failed_to_parse(dsl_val)
        return

    null_val = xlate_ctx.get_null_value()
    res = myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                 myexpr.ExprOpndColumnRef(col),
                                 myexpr.ExprOpndLiteral(null_val))
    return myexpr.gen_unary_expr(myexpr.OPR_NEG, res)

#https://www.elastic.co/guide/en/elasticsearch/reference/2.4/query-dsl-term-query.html
def analyze_term(dsl_key, dsl_val, xlate_ctx):
    #pylint: disable=unused-argument
    assert dsl_key == 'term'
    col, col_value = get_single_kv_pair(dsl_val)

    return myexpr.gen_binary_expr(myexpr.OPR_EQ,
                                  myexpr.ExprOpndColumnRef(col),
                                  myexpr.ExprOpndLiteral(col_value))

# https://www.elastic.co/guide/en/elasticsearch/reference/2.4/query-dsl-terms-query.html
def analyze_terms(dsl_key, dsl_val, xlate_ctx):
    #pylint: disable=unused-argument
    # e.g:
    # "terms" : {"user1": ["a", "b"], "user2": ["c", "d"]}
    #  =>
    # (user1 == a or user1 == b) and (user2 == c or user2 == d)
    #
    assert dsl_key == 'terms'
    bool_expr = []

    for col_name in dsl_val:
        col_opnd = myexpr.ExprOpndColumnRef(col_name)
        val_list = dsl_val[col_name]
        opnds = [myexpr.gen_binary_expr(myexpr.OPR_EQ, col_opnd,
                                        myexpr.ExprOpndLiteral(lit))
                 for lit in val_list]
        bool_expr.append(myexpr.gen_nary_or_expr(opnds))
    return myexpr.gen_nary_and_expr(bool_expr)


def _gen_column_cmp_expr(opr, col_name, lit_val, xlate_ctx):
    """
        internal funciton which return an expression comparing a column against
        the given operand
    """
    lit_opnd = myexpr.ExprOpndLiteral(lit_val)
    schema = xlate_ctx.get_schema()
    if schema.is_time_type(col_name):
        bk_db = xlate_ctx.get_conf().get_backend_db()

        in_mills = len(str(int(lit_val))) >= 11
        if bk_db.cmp_ts_column_using_str():
            col_expr = myexpr.ExprOpndColumnRef(col_name)
            epoch_in_s = int(lit_val) / 1000 if in_mills else int(lit_val)
            time_str = datetime.datetime.utcfromtimestamp(epoch_in_s).strftime('%Y-%m-%d %H:%M:%S')
            lit_opnd = myexpr.ExprOpndLiteral(time_str)
        else:
            if in_mills:
                col_expr = bk_db.get_ts_in_millis(col_name)
            else:
                col_expr = bk_db.get_ts_in_seconds(col_name)

        return myexpr.gen_binary_expr(opr, col_expr, lit_opnd)

    if schema.is_int_type(col_name):
        lit_opnd = myexpr.ExprOpndLiteral(int(lit_val))
    elif schema.is_float_type(col_name):
        lit_opnd = myexpr.ExprOpndLiteral(float(lit_val))

    return myexpr.gen_binary_expr(opr,
                                  myexpr.ExprOpndColumnRef(col_name),
                                  lit_opnd)



# https://www.elastic.co/guide/en/elasticsearch/reference/2.4/query-dsl-range-query.html
def analyze_range(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'range'
    k, v = get_single_kv_pair(dsl_val)

    low_end, high_end = None, None
    low_opr, high_opr = None, None

    # analyze the range
    assert isinstance(v, dict)
    for ri in v:
        end_val = v[ri]
        if ri in ('from', 'gte', 'gt'):
            low_end = end_val
            low_opr = myexpr.OPR_GTE
        elif ri in ('to', 'lte', 'lt'):
            high_end = end_val
            high_opr = myexpr.OPR_LTE
        else:
            not_supported(ri)

        if ri == 'gt':
            low_opr = myexpr.OPR_GT
        elif ri == 'lt':
            high_opr = myexpr.OPR_LT

    expr1, expr2 = None, None
    if low_opr is not None:
        expr1 = _gen_column_cmp_expr(low_opr, k, low_end, xlate_ctx)

    if high_opr is not None:
        expr2 = _gen_column_cmp_expr(high_opr, k, high_end, xlate_ctx)

    if expr1 is not None and expr2 is not None:
        return myexpr.gen_binary_expr(myexpr.OPR_AND, expr1, expr2)

    return expr1 if expr1 is not None else expr2


###########################################################################
#
#           compound expr handler
#
###########################################################################
#


def analyze_should(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'should'
    exprs = []
    for entry_iter in dsl_val:
        be = _analyze_block(entry_iter, xlate_ctx)
        if be is not None:
            exprs.append(be)
    return myexpr.gen_nary_or_expr(exprs)


def analyze_must(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'must'

    # case 1: the value contains a single block
    # e.g {"must": {"user": "david"}}
    if isinstance(dsl_val, dict):
        return _analyze_block(dsl_val, xlate_ctx)

    # case 2: the value is a list of blocks
    # e.g {"must": [{...}, {...}]
    exprs = []
    for must_entry in dsl_val:
        be = _analyze_block(must_entry, xlate_ctx)
        if be is not None:
            exprs.append(be)
    return gen_nary_and_expr_wrap(exprs)


def analyze_must_not(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'must_not'
    exprs = []

    for must_not_entry in dsl_val:
        be = _analyze_block(must_not_entry, xlate_ctx)
        if be is not None:
            exprs.append(be)

    return myexpr.gen_unary_expr(myexpr.OPR_NEG, myexpr.gen_nary_or_expr(exprs))


# https://docs.google.com/document/d/1MtK2LOB7gQANGwK4GwyqfRPj1P7v_Mo1yDsvIn9R8JA/edit#heading=h.mcx6jh1ce4r2
def analyze_bool(dsl_key, dsl_val, xlate_ctx):
    assert dsl_key == 'bool'

    # TODO: handle minimum_should_match
    if 'minimum_should_match' in dsl_val:
        if dsl_val['minimum_should_match'] != 1:
            not_supported('minimum_should_match', 'bool')

    exprs = []
    for ki in dsl_val:
        exprs.append(analyze_boolean_expr(ki, dsl_val[ki], xlate_ctx))
    return gen_nary_and_expr_wrap(exprs)


##################################################################
#
#       Following are driver functions
#
##################################################################
#


def _skip(dsl_key, dsl_val, xlate_ctx):
    bool_exprs = []
    ignore_keys = ignore_attribute.get(dsl_key, [])
    for ki in dsl_val:
        if ki in ignore_keys:
            continue

        rc = analyze_boolean_expr(ki, dsl_val[ki], xlate_ctx)
        if rc is not None:
            bool_exprs.append(rc)
    return gen_nary_and_expr_wrap(bool_exprs)


def _init_dispatch():
    global compound_dispatch
    global leaf_dispatch
    global compound_keys
    global leaf_keys

    if compound_dispatch is not None and \
       leaf_dispatch is not None:
        return

    compound_dispatch = {
        'filter': _skip,
        'query': _skip,
        'fquery': _skip,
        'must': analyze_must,
        'must_not': analyze_must_not,
        'should': analyze_should,
        'bool': analyze_bool,
        'filtered': _skip
    }

    leaf_dispatch = {
        'term':  analyze_term,
        'terms': analyze_terms,
        'range': analyze_range,
        'query_string': analyze_query_string,
        'match': analyze_match,
        'match_phrase': analyze_match_phrase,
        'exists': analyze_exists
    }

    compound_keys = compound_dispatch.keys()
    leaf_keys = leaf_dispatch.keys()


def _analyze_block(dsl_blk, xlate_ctx):
    assert isinstance(dsl_blk, dict)

    bool_expr = []
    for k in dsl_blk:
        be = analyze_boolean_expr(k, dsl_blk[k], xlate_ctx)
        bool_expr.append(be)
    return gen_nary_and_expr_wrap(bool_expr)


def analyze_block(dsl_blk, xlate_ctx):
    return _analyze_block(dsl_blk, xlate_ctx)


def analyze_boolean_expr(dsl_key, dsl_val, xlate_ctx):
    _init_dispatch()

    if dsl_key in compound_dispatch:
        return compound_dispatch[dsl_key](dsl_key, dsl_val, xlate_ctx)
    elif dsl_key in leaf_dispatch:
        return leaf_dispatch[dsl_key](dsl_key, dsl_val, xlate_ctx)

    not_supported(dsl_key, context=json.dumps({dsl_key: dsl_val}))


# init define-once global variables
_init_dispatch()
