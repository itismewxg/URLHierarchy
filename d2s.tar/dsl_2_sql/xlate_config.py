# pylint: disable=missing-docstring,invalid-name,fixme

import os
import yaml

from db_backend import db_backend_impl

class AppConfig(object):
    def __init__(self, conf=None, conf_dict=None):
        self._default_conf_path = os.path.dirname(os.path.realpath(__file__)) + "/../conf/app.conf"

        if conf_dict is not None:
            self._conf = conf_dict
        else:
            conf_file = conf
            if conf is None:
                conf_file = self._default_conf_path

            with open(conf_file) as f:
                self._conf = yaml.load(f.read())

        self._backend_db_name = self._conf.get('backend_db', 'bigquery')
        self._backend_db = db_backend_impl.BackendDB(self._backend_db_name, self._conf)
        self.memcached_host = self._conf.get('memcached_host', None)
        self.memcached_port = self._conf.get('memcached_port', None)
        self.memcached_schema_expired_time = self._conf.get('memcached_schema_expired_time', None)
        self.memcached_timestamp_field_expired_time = self._conf.get('memcached_timestamp_field_expired_time', None)
        # ts_map for setting the initial data in Memcached
        self.ts_map = self._conf.get("ts_map", None)

    def time_in_millis(self, tab_name=None):
        # pylint: disable=unused-argument
        rc = self._conf.get('time_in_millis', None)
        if rc is not None:
            return rc

        # TODO: handle table specific configuration
        assert False

    def get_memcached_host(self):
        return self.memcached_host

    def get_memcached_port(self):
        return self.memcached_port

    def get_memcached_schema_expired_time(self):
        return self.memcached_schema_expired_time

    def get_memcached_timestamp_field_expired_time(self):
        return self.memcached_timestamp_field_expired_time

    def get_config_parameter(self, input_key):
        return self._conf.get(input_key, None)

    def get_ts_map(self):
        return self.ts_map

    def get_backend_db_name(self):
        return self._backend_db_name


    def get_backend_db(self):
        return self._backend_db


    def enable_expr_optimization(self):
        return self._conf.get('enable_expr_opt', True)

    def get_log_path(self):
        return self._conf.get('log', {}).get('path')

    def get_log_rotate_size(self):
        return self._conf.get('log', {}).get('rotate_size')

    def get_log_rotate_num(self):
        return self._conf.get('log', {}).get('rotate_num')

    def is_log_compression_enabled(self):
        return self._conf.get('log', {}).get('compress', False)

    def get_listen_ip(self):
        return self._conf.get('listen', {}).get('ip')

    def get_dataset_location(self):
        """
        return the location of BigQuery's dataset location, return "US" if
        this configuration is not present
        """
        return self._conf.get('dataset_location', 'US')

    def get_listen_port(self):
        return self._conf.get('listen', {}).get('port')

    def get_conf(self, key):
        return self._conf.get(key, None)


class XlateContext(object):
    def __init__(self, conf, schema, col_name_map=None):
        if conf is None:
            conf = AppConfig()
        if col_name_map is None:
            col_name_map = {}

        self._conf = conf
        self._schema = schema
        self._col_name_map = col_name_map
        self._non_null_columns = []

    def get_conf(self):
        return self._conf

    def get_schema(self):
        return self._schema

    def set_schema(self, schema):
        self._schema = schema

    def get_current_table(self):
        return self._schema.get_table_name()

    def xlate_to_db_column_name(self, dsl_column):
        '''
           ES DSL's field name is not necessarilly equal to the backend-db's
           column name; the translation is conducted by this func
        '''
        return self._col_name_map.get(dsl_column, dsl_column)

    def set_non_null_columns(self, non_null):
        self._non_null_columns = non_null

    def get_non_null_columns(self):
        return self._non_null_columns

    # https://www.elastic.co/guide/en/elasticsearch/reference/current/null-value.html
    # TODO: move the logic to Schema class?
    def get_null_value(self):
        return 'null'


if __name__ == '__main__':
    app_config = AppConfig()
    print(app_config.ts_map)
