from sets import Set


class TranslateLeafQueryClause(object):
    def __init__(self):
        pass

    @staticmethod
    def operator_set():
        return Set(['match', 'term', 'range'])
