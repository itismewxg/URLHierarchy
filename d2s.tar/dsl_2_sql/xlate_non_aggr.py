#pylint: disable=missing-docstring,too-few-public-methods,relative-import

import xlate_sql_expr as myexpr
from xlate_condition import analyze_block
from xlate_utils import get_single_kv_pair

from dsl_2_sql.xlate_null_analysis import insert_column_neq_null_condition


class NonAggregation(object):
    def __init__(self, dsl_blk, ctx):
        self._dsl = dsl_blk
        self._ctx = ctx
        self._condition_expr = None
        self._limit_n = None
        self._sort = None
        self._analyze()

    ###########################################################################
    # sort examples:
    # e.g 1
    #
    # "sort" : [
    #         { "post_date" : {"order" : "asc"}},
    #         "user",
    #         { "name" : "desc" },
    #         { "age" : "desc" },
    #         "_score"
    #     ],
    #
    # e.g 2
    #   { "sort": {"_score": { "order": "desc" }}}
    #
    # e.g.3
    #   { "sort": { "colname": { "order": "desc" }}}
    #
    ###########################################################################
    @staticmethod
    def _analyze_sort_entry(sort_list, sort_entry):
        if isinstance(sort_entry, str):
            # e.g. "user" in the above example 1
            sort_list.append((str(sort_entry), 'A'))
            return sort_list

        if isinstance(sort_entry, dict):
            col_name, order_spec = get_single_kv_pair(sort_entry)
            if type(order_spec) == dict:
                order_spec = order_spec['order']

            sort_list.append((str(col_name), 'A' if order_spec == 'asc' else 'D'))
            return sort_list

    @staticmethod
    def _analyze_sort(val):
        if type(val) == dict:
            return NonAggregation._analyze_sort_entry([], val)

        sort_list = []
        for entry_iter in val:
            sort_list = NonAggregation._analyze_sort_entry(sort_list, entry_iter)

        return sort_list

    def _analyze(self):
        dsl = self._dsl

        for key in dsl:
            val = dsl[key]
            if key in ['filtered', 'query']:
                self._condition_expr = analyze_block(val, self._ctx)
                continue

            if key == 'highlight':
                # ignore it for now
                continue

            if key == 'size':
                self._limit_n = int(val)
                continue

            if key == 'sort':
                self._sort = self._analyze_sort(val);

        if self._condition_expr is None:
            raise Exception("no condition specified")

        if self._limit_n is None:
            raise Exception("no limit specified")

        if self._limit_n > 10000:
            raise Exception("try to pull too many data")

    def emit_sql(self):
        tab_name = self._ctx.get_current_table()
        db_backend = self._ctx.get_conf().get_backend_db()
        sql = db_backend.emit_pretty_print_select_all_sql(tab_name)
        sql = sql.rstrip() + "\n"

        if self._condition_expr is not None:
            insert_column_neq_null_condition(self._condition_expr, self._ctx)
            where_clause = "WHERE %s\n" % (\
                myexpr.emit_expr(self._condition_expr, self._ctx))
            sql = sql + where_clause

        if self._sort is not None:
            order_by_strs = []
            for ci in self._sort:
                col_name = ci[0]
                asc = ci[1]
                emit_col_name = self._ctx.xlate_to_db_column_name(col_name)

                if col_name != "_score":
                    clause = "%s %s" % (emit_col_name, 'ASC' if asc == 'A' else 'DESC')
                    order_by_strs.append(clause)
            if len(order_by_strs) != 0:
                orderby_clause = "ORDER BY %s\n" % (', '.join(order_by_strs))
                sql = sql + orderby_clause

        if self._limit_n is not None:
            limit_clause = "LIMIT %d\n" % self._limit_n
            sql = sql + limit_clause

        addition_info = {}
        if self._sort is not None:
            addition_info["sort"] = [sort_col[0] for sort_col in self._sort]

        return sql, 'listView', None, addition_info
