#pylint: disable=missing-docstring,relative-import,invalid-name,len-as-condition
#pylint: disable=inconsistent-return-statements,unused-wildcard-import
#pylint: disable=wildcard-import

import copy
from xlate_sql_expr import *
from xlate_sql_expr_transform import expr_promote_to_nary

EXPLICIT_NULL = "explict_null"
IMPLICIT_NULL = "implict_null"

def _intersect_sets(sets):
    result = None
    for x in sets:
        if x is None:
            return None

        if result is None:
            result = x
        else:
            result = result.intersection(x)

    if len(result) != 0:
        return result


def _union_sets(sets):
    result = set()
    for x in sets:
        if x is not None:
            result = result.union(x)

    if len(result) != 0:
        return result


def _union_two_sets(x, y):
    result = None

    if x is None:
        result = y
    elif y is None:
        result = x
    else:
        result = x.union(y)

    if result is not None and len(result) != 0:
        return result


def _intersect_two_sets(x, y):
    if x is None or y is None:
        return

    result = x.intersect(y)
    if len(result) != 0:
        return result


def _diff_two_sets(x, y):
    if x is None:
        return

    result = None
    if y is None:
        result = x
    else:
        result = x.difference(y)

    if result is not None and len(result) != 0:
        return result


def _analyze_null_value_r(expr, ctx):
    if not isinstance(expr, Expr):
        return

    expr.erase_keyed_annot(EXPLICIT_NULL)

    opc = expr.get_opr().get_opcode()
    if opc in (OPR_N_AND, OPR_AND):
        return _analyze_AND_expr_null_value(expr, ctx)

    if opc in (OPR_N_OR, OPR_OR):
        return _analyze_OR_expr_null_value(expr, ctx)

    if opc == OPR_NEG:
        return _analyze_null_value_r(expr.get_opnd0(), ctx)

    # check "cmd == null" expr
    if opc == OPR_EQ and is_null(expr.get_opnd1(), ctx):
        rc = {expr.get_opnd0().get_column_name()}
        expr.set_keyed_annot(EXPLICIT_NULL, rc)
        return rc

    # other exprs
    for x in expr.get_opnds():
        _analyze_null_value_r(x, ctx)


def _analyze_AND_expr_null_value(expr, ctx):
    results = [_analyze_null_value_r(x, ctx) for x in expr.get_opnds()]
    explict_null = _union_sets(results)

    if explict_null is not None and len(explict_null) != 0:
        expr.set_keyed_annot(EXPLICIT_NULL, explict_null)
        return explict_null


def _analyze_OR_expr_null_value(expr, ctx):
    results = [_analyze_null_value_r(x, ctx) for x in expr.get_opnds()]
    explict_null = _intersect_sets(results)

    if explict_null is not None and len(explict_null) != 0:
        return explict_null


def _propagate_explict_null_topdown_r(expr, enclosing_expr_explict_null):
    if not isinstance(expr, Expr):
        return

    explict_null = _union_two_sets(expr.get_keyed_annot(EXPLICIT_NULL),
                                   enclosing_expr_explict_null)

    for x in expr.get_opnds():
        _propagate_explict_null_topdown_r(x, explict_null)


def _analyze_null_value(expr, ctx):
    expr_promote_to_nary(expr)
    _analyze_null_value_r(expr, ctx)
    _propagate_explict_null_topdown_r(expr, None)


def _insert_coloumn_neq_null_helper(expr, ctx, columns):
    if columns is None:
        return

    opnds = [copy.deepcopy(expr)]
    for x in sorted(columns):
        # sorted() is to ease testing
        opnds.append(gen_column_ne_null(x, ctx))

    expr.copy(gen_nary_and_expr(opnds))
    explict_set = _union_two_sets(expr.get_keyed_annot(EXPLICIT_NULL), columns)
    expr.set_keyed_annot(EXPLICIT_NULL, explict_set)


def _insert_column_neq_null_condition_r(expr, ctx):
    if not isinstance(expr, Expr):
        return

    expr.erase_keyed_annot(IMPLICIT_NULL)
    for x in expr.get_opnds():
        _insert_column_neq_null_condition_r(x, ctx)

    opc = expr.get_opr().get_opcode()

    annots = []
    if ctx.get_non_null_columns():
        annots.append(set(ctx.get_non_null_columns()))

    for x in expr.get_opnds():
        if isinstance(x, Expr):
            _insert_column_neq_null_condition_r(x, ctx)
            annots.append(x.get_keyed_annot(IMPLICIT_NULL))
            continue

        if isinstance(x, ExprOpndColumnRef):
            annots.append({x.get_column_name()})

    if opc in (OPR_N_OR, OPR_OR):
        common_implict_null = _diff_two_sets(_intersect_sets(annots), \
            expr.get_keyed_annot(EXPLICIT_NULL))

        expr.set_keyed_annot(IMPLICIT_NULL, common_implict_null)

        for x in expr.get_opnds():
            if not isinstance(expr, Expr):
                continue

            sub_expr_implict_null = _diff_two_sets(\
                x.get_keyed_annot(IMPLICIT_NULL), common_implict_null)

            _insert_coloumn_neq_null_helper(x, ctx, sub_expr_implict_null)

        return

    implict_null = _diff_two_sets(_union_sets(annots), \
                                  expr.get_keyed_annot(EXPLICIT_NULL))

    expr.set_keyed_annot(IMPLICIT_NULL, implict_null)


def _insert_column_neq_null_condition(expr, ctx):
    _insert_column_neq_null_condition_r(expr, ctx)
    implict_null = expr.get_keyed_annot(IMPLICIT_NULL)
    _insert_coloumn_neq_null_helper(expr, ctx, implict_null)


# to insert "column is not null" condition wherever fit
def insert_column_neq_null_condition(expr, ctx):
    _analyze_null_value(expr, ctx)
    _insert_column_neq_null_condition(expr, ctx)
