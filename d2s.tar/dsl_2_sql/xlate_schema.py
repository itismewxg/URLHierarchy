class Schema(object):
    def __init__(self, tab_name, schema):
        """
        the schema can be a dict or a function
        """
        self._tab_name = tab_name
        self._schema = schema


    def get_table_name(self):
        return self._tab_name


    def get_column_type(self, col_name):
        # NOTE: the schema can be specified by either a labmda function
        # or a plain dict. Also, the type-of-a-cloumn can be respented either
        # by a string (e.g. "integer") or a dict which contains info more than
        # just the type of the column, but other attributes, say if the column
        # is nullable etc.
        #
        if callable(self._schema):
            ty = self._schema(col_name)
        else:
            ty = self._schema.get(col_name)

        if isinstance(ty, dict):
            return ty.get('type')
        return ty


    def is_boolean_type(self, col_name):
        ty = self.get_column_type(col_name)
        if ty is not None and ty.lower() in ['bool', 'boolean']:
            return True
        return False


    def is_time_type(self, col_name):
        ty = self.get_column_type(col_name)
        if ty is not None and ty.lower() in ['date', 'timestamp']:
            return True
        return False

    def is_int_type(self, col_name):
        ty = self.get_column_type(col_name)
        if ty is not None and ty.lower() in ['integer', 'int', 'int64', 'long']:
            return True
        return False

    def is_float_type(self, col_name):
        ty = self.get_column_type(col_name)
        if ty is not None and ty.lower() in ['double', 'float64', 'number', 'float']:
            return True
        return False
