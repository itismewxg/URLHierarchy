#pylint: disable=fixme,invalid-name,missing-docstring,too-few-public-methods

class Column(object):
    def __init__(self, expr, orderby=None, orderby_asc=None):
        self.expr = expr
        self.name = None
        self.index = None
        self.emit_string = None
        self.orderby = orderby
        self.orderby_asc = orderby_asc

    def __eq__(self, other):
        return self.expr == other.expr and \
               self.orderby == other.orderby and \
               self.orderby_asc == other.orderby_asc
