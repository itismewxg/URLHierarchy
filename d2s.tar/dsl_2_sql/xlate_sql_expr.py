#pylint: disable=missing-docstring,invalid-name,inconsistent-return-statements
#pylint: disable=global-statement,fixme,line-too-long

###########################################################################
#
#           This part is about operator
#
###########################################################################
#


import numbers
import copy
#import xlate_config


# unary operator
OPR_NEG = 0
OPR_DEGENERATE = 1    # expr taking a literal operand
OPR_UNARY_FIRST = 0
OPR_UNARY_LAST = 1

# binary operator
OPR_AND = 100
OPR_OR = 101
OPR_GTE = 102
OPR_GT = 103
OPR_LTE = 104
OPR_LT = 105
OPR_EQ = 106
OPR_MATCH = 107
OPR_ADD = 108
OPR_SUB = 109
OPR_DIV = 110
OPR_MUL = 111
OPR_BINARY_FIRST = 100
OPR_BINARY_LAST = 111

# n-ary operator
OPR_N_AND = 400
OPR_N_OR = 401
OPR_CALL = 402
OPR_VERSATILE_LIST = 403
OPR_NARY_FIRST = 400
OPR_NARY_LAST = 403

# operator precedence
# Look like Microsoft and Orcale has discrepancy of precedence of 'LIKE'
# operator. WTF! Not knowing how to define the precedence right, we
# enclose OPR_MATCH with parenthesis.
#
# o. https://docs.oracle.com/cd/B14117_01/server.101/b10759/conditions001.htm
# o. https://docs.microsoft.com/en-us/sql/t-sql/language-elements/operator-precedence-transact-sql?view=sql-server-2017
#
_opr_precedence = {
    0: {OPR_DEGENERATE},
    1: {OPR_CALL, OPR_VERSATILE_LIST},
    2: {OPR_MUL, OPR_DIV},
    3: {OPR_ADD, OPR_SUB},
    4: {OPR_GTE, OPR_GT, OPR_LTE, OPR_LT, OPR_EQ, OPR_MATCH},
    5: {OPR_NEG},
    6: {OPR_AND, OPR_N_AND},
    7: {OPR_OR, OPR_N_OR}
}


highest_precedence = 0
least_precedence = 7
lower_than_least_precedence = least_precedence + 1

# associativity, left-to-right by default
_right_to_left_associativity = [OPR_NEG]

_opr_name = {
    OPR_NEG: "NOT",
    OPR_AND: "AND",
    OPR_OR:  "OR",
    OPR_GTE: ">=",
    OPR_GT:  ">",
    OPR_LTE: "<=",
    OPR_LT:  "<",
    OPR_EQ:  "=",
    OPR_ADD: "+",
    OPR_SUB: "-",
    OPR_MUL: "*",
    OPR_DIV: "/",
    OPR_MATCH: "LIKE",
    OPR_N_AND: "N_AND",
    OPR_N_OR:  "N_OR",
    OPR_CALL:  "N/A",
    OPR_VERSATILE_LIST:  "N/A",
    OPR_DEGENERATE:  "N/A"
}

_commutative_opr = [
    OPR_AND, OPR_OR, OPR_EQ, OPR_ADD, OPR_MUL, OPR_N_AND, OPR_N_OR
]


class OprTrait(object):
    def __init__(self, opcode, opr_str):
        self.opcode = opcode
        self.name = opr_str
        self.precedence = 1000

        # check the precedence
        for pi in _opr_precedence:
            oprs = _opr_precedence[pi]
            if opcode in oprs:
                self.precedence = pi
                break

        assert self.precedence != 1000

        # set the associativity
        self.associativity = 'r' if opcode in _right_to_left_associativity else 'l'

    def get_name(self):
        return self.name

    def is_binary(self):
        return self.opcode >= OPR_BINARY_FIRST and self.opcode <= OPR_BINARY_LAST

    def is_unary(self):
        return self.opcode >= OPR_UNARY_FIRST and self.opcode <= OPR_UNARY_LAST

    def is_nary(self):
        return self.opcode >= OPR_NARY_FIRST and self.opcode <= OPR_NARY_LAST

    def is_commutative(self):
        return self.opcode in _commutative_opr


_opr_trait = None
def get_opr_trait(opr):
    global _opr_trait

    if _opr_trait is None:
        _opr_trait = {}
        for opr_iter in _opr_name:
            _opr_trait[opr_iter] = OprTrait(opr_iter, _opr_name[opr_iter])

    return _opr_trait[opr]


class ExprOpr(object):
    def __init__(self, opcode):
        self._opr_trait = get_opr_trait(opcode)
        self._opnd_num = -1

        if self.is_unary():
            self._opnd_num = 1
        elif self.is_binary():
            self._opnd_num = 2
        elif not self.is_nary():
            raise Exception('illegal operator ' + str(opcode))

    def get_opcode(self):
        return self._opr_trait.opcode

    def get_opr_name(self):
        return self._opr_trait.name

    def get_precedence(self):
        return self._opr_trait.precedence

    def get_associativity(self):
        return self._opr_trait.associativity

    def is_binary(self):
        return self._opr_trait.is_binary()

    def is_unary(self):
        return self._opr_trait.is_unary()

    def is_nary(self):
        return self._opr_trait.is_nary()

    def get_opnd_num(self):
        return self._opnd_num

    def is_commutative(self):
        return self._opr_trait.is_commutative()

    def __eq__(self, other):
        #pylint: disable=protected-access
        return self._opr_trait.opcode == other._opr_trait.opcode

    def __ne__(self, other):
        # only necessary for python 2
        return not self.__eq__(other)

    def dump(self):
        return str(self._opr_trait.opcode)


###########################################################################
#
#               This part is about operand
#
###########################################################################
#


class ExprOpndBase(object):
    TY_LITERAL = 1
    TY_COLUMN_REF = 2
    TY_AGGREGATION = 3
    TY_EXPR = 4

    def __init__(self, ty):
        self._ty = ty

    def __eq__(self, that):
        assert False

    def __ne__(self, that):
        assert False


class ExprOpndLiteral(ExprOpndBase):
    def __init__(self, lit, **kwargs):
        super(ExprOpndLiteral, self).__init__(self.TY_LITERAL)
        self._literal = lit
        self._kwargs = kwargs

    def get_literal(self):
        return self._literal

    def no_quote(self):
        return self._kwargs.get('no_quote')

    def __eq__(self, that):
        #pylint: disable=protected-access
        return isinstance(that, ExprOpndLiteral) and \
               self._literal == that._literal

    def __ne__(self, that):
        return not self == that

    def dump(self):
        return str(self._literal)


class ExprOpndColumnRef(ExprOpndBase):
    def __init__(self, column_name, column_alias=None):
        super(ExprOpndColumnRef, self).__init__(self.TY_COLUMN_REF)
        self._column_name = column_name
        self._column_alias = column_alias

    def get_column_name(self):
        return self._column_name

    def get_column_alias(self):
        return self._column_alias

    def __eq__(self, that):
        #pylint: disable=protected-access
        return isinstance(that, ExprOpndColumnRef) and \
               self._column_name == that._column_name and \
               self._column_alias == that._column_alias

    def __ne__(self, that):
        return not self.__eq__(that)

    def dump(self):
        return "column:" + self._column_name


def gen_keyword(kw):
    return ExprOpndLiteral(str(kw), no_quote=True)


class ExprAnnotation(object):
    def __init__(self):
        self._fold_to = None
        self._keyed_annot = {}

    def is_True(self):
        return self._fold_to is True

    def is_False(self):
        return self._fold_to is False

    def set_folded_const(self, const_val):
        self._fold_to = const_val

    def is_constant(self):
        return self._fold_to is not None

    def get_keyed_annot(self, key):
        return self._keyed_annot.get(key)

    def set_keyed_annot(self, key, annot):
        if annot is None:
            self.erase_keyed_annot(key)
        else:
            self._keyed_annot[key] = annot

    def erase_keyed_annot(self, key):
        if key in self._keyed_annot:
            del self._keyed_annot[key]


###########################################################################
#
#               This part is about expression
#
###########################################################################
#
class Expr(ExprOpndBase):
    def __init__(self, opcode, opnd0, *opnds):
        # NOTE: keep in sync with Expr.copy()
        super(Expr, self).__init__(self.TY_EXPR)
        self._opr = ExprOpr(opcode)
        self._opnds = [opnd0]
        self._annot = None
        assert is_legal_opnd(opnd0)
        for oi in opnds:
            assert is_legal_opnd(oi)
            self._opnds.append(oi)

        if not self._opr.is_nary() and \
           len(self._opnds) != self._opr.get_opnd_num():
            raise Exception("incorrect number of operand number")

    def get_opr(self):
        return self._opr

    def get_opnds(self):
        return self._opnds

    def get_opnd0(self):
        return self._opnds[0]

    def get_opnd1(self):
        return self._opnds[1]

    def get_indiced_opnd(self, idx):
        return self._opnds[idx]

    def set_opnd(self, idx, new_opnd):
        self._opnds[idx] = new_opnd

    def set_opr_opnds(self, opr, new_opnds):
        self._opr = opr
        self._opnds = new_opnds

    def get_annot(self):
        return self._annot

    def get_or_create_annot(self):
        if self._annot is None:
            self._annot = ExprAnnotation()
        return self._annot

    def set_keyed_annot(self, key, val):
        self.get_or_create_annot().set_keyed_annot(key, val)

    def get_keyed_annot(self, key):
        if self._annot is not None:
            return self._annot.get_keyed_annot(key)

    def erase_keyed_annot(self, key):
        if self._annot is not None:
            self._annot.erase_keyed_annot(key)

    def __eq__(self, that):
        opr = self.get_opr()
        if not isinstance(that, Expr) or opr != that.get_opr():
            return False

        opnds_1 = self.get_opnds()
        opnds_2 = that.get_opnds()
        opnd_num = len(opnds_1)
        if opnd_num != len(opnds_2):
            return False

        if not opr.is_commutative():
            for oi in range(0, opnd_num):
                if opnds_1[oi] != opnds_2[oi]:
                    return False
            return True

        #TODO: this is O(n*n) complexity
        visited = [False] * opnd_num
        for opnd in opnds_1:
            found = False
            for oi in range(0, opnd_num):
                if not visited[oi] and opnd == opnds_2[oi]:
                    visited[oi] = True
                    found = True
                    break
            if not found:
                return False

        return True

    def __ne__(self, that):
        return not self.__eq__(that)

    def copy(self, src):
        #pylint: disable=protected-access
        # NOTE: keep in sync with __init__
        self._opr = copy.deepcopy(src._opr)
        self._opnds = copy.deepcopy(src._opnds)
        self._annot = copy.deepcopy(src._annot)

    def dump(self):
        opr_str = self._opr.dump()
        opnd_str = []
        for x in self._opnds:
            opnd_str.append(x.dump())

        return "(%s %s)" % (opr_str, ", ".join(opnd_str))

def is_legal_opnd(obj):
    return isinstance(obj, (ExprOpndLiteral, ExprOpndColumnRef, Expr))


def gen_unary_expr(opr, opnd):
    return Expr(opr, opnd)


def gen_degenerate_expr(opnd):
    return gen_unary_expr(OPR_DEGENERATE, opnd)

def gen_binary_expr(opr, opnd0, opnd1):
    return Expr(opr, opnd0, opnd1)


def gen_nary_expr(opr, opnd0, *opnds):
    opnd_num = len(opnds)
    assert opnd_num >= 1

    if opnd_num == 1:
        return opnds[0]

    return Expr(opr, opnd0, *opnds)

def gen_versatile_list(opnd_list):
    return gen_nary_expr(OPR_VERSATILE_LIST, opnd_list[0], *opnd_list[1:])

def gen_nary_or_expr(opnds):
    opnd_num = len(opnds)
    assert opnd_num >= 1

    if opnd_num == 1:
        return opnds[0]

    return Expr(OPR_N_OR, *opnds)


def gen_nary_and_expr(opnds):
    if not opnds:
        return get_true_expr()
    return Expr(OPR_N_AND, *opnds)


def gen_column_ne_null(col_name, ctx):
    e = gen_binary_expr(OPR_EQ, ExprOpndColumnRef(col_name), \
                        gen_null_opnd(ctx))
    return gen_unary_expr(OPR_NEG, e)


def gen_column_eq_null(col_name, ctx):
    return gen_binary_expr(OPR_EQ, ExprOpndColumnRef(col_name), \
                           gen_null_opnd(ctx))


def gen_call_expr(func_name, opnds):
    fname = func_name if isinstance(func_name, ExprOpndLiteral) \
            else ExprOpndLiteral(func_name)
    return Expr(OPR_CALL, fname, *opnds)


true_expr = None
false_expr = None

def get_true_expr():
    global true_expr
    if true_expr is None:
        true_expr = gen_binary_expr(OPR_EQ,
                                    ExprOpndLiteral(1),
                                    ExprOpndLiteral(1))
        true_expr.get_or_create_annot().set_folded_const(True)

    return true_expr

def get_false_expr():
    global false_expr
    if false_expr is None:
        false_expr = gen_binary_expr(OPR_EQ,
                                     ExprOpndLiteral(1),
                                     ExprOpndLiteral(0))
        false_expr.get_or_create_annot().set_folded_const(False)

    return false_expr


###########################################################################
#
#               Emit expression to string
#
###########################################################################
#


def emit_literal(lit, ctx):
    #pylint: disable=unused-argument
    assert isinstance(lit, ExprOpndLiteral)
    lit_val = lit.get_literal()
    if isinstance(lit_val, str):
        if lit.no_quote():
            # don't enclose keyword, say modifier, with quote
            return lit_val
        return "'%s'"% lit_val

    if isinstance(lit_val, bool):
        return "TRUE" if lit_val else "FALSE"

    if isinstance(lit_val, numbers.Number):
        return lit_val

    return str(lit_val)


def emit_column_ref(ref, ctx):
    name = ref.get_column_name()
    if name is None:
        name = ref.get_column_alias()
    name = ctx.xlate_to_db_column_name(name)

    return ctx.get_conf().get_backend_db().emit_column_name(name)


def emit_opnd(opnd, opr_precedence, ctx):
    #assert isinstance(ctx, xlate_config.XlateContext)
    if isinstance(opnd, ExprOpndLiteral):
        return emit_literal(opnd, ctx)

    if isinstance(opnd, ExprOpndColumnRef):
        return emit_column_ref(opnd, ctx)

    opnd_str = emit_expr(opnd, ctx)
    if opnd.get_opr().get_precedence() > opr_precedence:
        return "(%s)" % opnd_str
    return opnd_str


def lower_nary(expr):
    opr = expr.get_opr()
    opcode = opr.get_opcode()
    opnds = expr.get_opnds()

    if opcode == OPR_N_AND:
        new_opr = OPR_AND
    elif opcode == OPR_N_OR:
        new_opr = OPR_OR
    else:
        raise Exception("unknown nary operator %d" % opcode)

    result = opnds[0]
    for idx in range(1, len(opnds)):
        result = gen_binary_expr(new_opr, result, opnds[idx])
    return result


def emit_call(expr, ctx):
    opr = expr.get_opr()
    assert opr.get_opcode() == OPR_CALL
    opnds = expr.get_opnds()

    func_name = opnds[0].get_literal()

    if func_name == 'sql_cast':
        assert len(opnds) == 3
        return "cast(%s as %s)" % (emit_opnd(opnds[1], least_precedence + 1, ctx),
                                   opnds[2].get_literal())

    opnd_strs = [emit_opnd(x, least_precedence + 1, ctx) for x in opnds[1:]]
    return "%s(%s)" % (func_name, ", ".join(opnd_strs))


def emit_nary(expr, ctx, lower_nary_expr=True):
    opr = expr.get_opr()
    opcode = opr.get_opcode()
    precedence = opr.get_precedence()
    opr_name = opr.get_opr_name()

    if lower_nary_expr and opcode in [OPR_N_AND, OPR_N_OR]:
        lowered = lower_nary(expr)
        return emit_expr(lowered, ctx)

    if opcode != OPR_CALL:
        opnd_strs = []
        opnds = expr.get_opnds()
        for opnd_iter in opnds:
            opnd_strs.append(str(emit_opnd(opnd_iter, precedence, ctx)))

        if opcode == OPR_VERSATILE_LIST:
            result = " ".join(opnd_strs)
        else:
            result = "(%s %s)" % (opr_name, ", ".join(opnd_strs))
    else:
        result = emit_call(expr, ctx)

    return result


def is_null(opnd, ctx):
    if not isinstance(opnd, ExprOpndLiteral):
        return False

    lit_val = opnd.get_literal()
    if not isinstance(lit_val, str):
        return False

    return lit_val.lower() == ctx.get_null_value()


def gen_null_opnd(ctx):
    return ExprOpndLiteral(ctx.get_null_value())


def _extract_column_names_r(expr):
    if isinstance(expr, ExprOpndColumnRef):
        return {expr.get_column_name()}

    result = set()
    if isinstance(expr, Expr):
        for x in expr.get_opnds():
            result = result.union(_extract_column_names_r(x))

    return result


def extract_column_names(expr):
    return _extract_column_names_r(expr)


def emit_binary(expr, ctx):
    opr = expr.get_opr()
    opcode = opr.get_opcode()
    precedence = opr.get_precedence()
    opr_name = opr.get_opr_name()

    if opcode == OPR_MATCH:
        opnd0_str = emit_opnd(expr.get_opnd0(), precedence, ctx)
        opnd1_str = "'%%%s%%'" % expr.get_opnd1().get_literal()
        # I don't know the 'like' precedence, add parentheses to be safe
        return "(%s %s %s)" % (opnd0_str, opr_name, opnd1_str)

    if opcode == OPR_EQ and is_null(expr.get_opnd1(), ctx):
        opnd0_str = emit_opnd(expr.get_opnd0(), precedence, ctx)
        # NOTE: now that we change the operator, we need to add parenthesis
        #  to be safe
        return "(%s IS NULL)" % opnd0_str

    opnd0_str = emit_opnd(expr.get_opnd0(), precedence, ctx)
    opnd1_str = emit_opnd(expr.get_opnd1(), precedence, ctx)
    return "%s %s %s" % (opnd0_str, opr_name, opnd1_str)


def emit_negation(expr, ctx):
    opr = expr.get_opr()
    precedence = opr.get_precedence()
    opr_name = opr.get_opr_name()

    subexpr = expr.get_opnd0()

    # special cases "not (x == null)" => "x IS NOT NULL"
    if isinstance(subexpr, Expr) and \
       subexpr.get_opr().get_opcode() == OPR_EQ and \
       is_null(subexpr.get_opnd1(), ctx):
        # note the highest_precedence is to avoid placing () around the
        # column name
        opnd0_str = emit_opnd(subexpr.get_opnd0(), highest_precedence, ctx)
        return "(%s IS NOT NULL)" % opnd0_str

    opnd_str = emit_opnd(expr.get_opnd0(), precedence, ctx)
    return "%s %s" % (opr_name, opnd_str)


def emit_expr(expr, ctx, lower_nary_expr=True):
    #assert isinstance(ctx, xlate_config.XlateContext)
    opr = expr.get_opr()
    precedence = opr.get_precedence()
    opr_name = opr.get_opr_name()

    if opr.is_unary():
        if opr.get_opcode() == OPR_DEGENERATE:
            return emit_opnd(expr.get_opnd0(), lower_than_least_precedence, ctx)

        if opr.get_opcode() == OPR_NEG:
            return emit_negation(expr, ctx)

        opnd_str = emit_opnd(expr.get_opnd0(), precedence, ctx)
        return "%s %s" % (opr_name, opnd_str)

    if opr.is_binary():
        return emit_binary(expr, ctx)

    assert opr.is_nary()
    return emit_nary(expr, ctx, lower_nary_expr)
