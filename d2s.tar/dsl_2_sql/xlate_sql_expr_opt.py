#pylint: disable=missing-docstring,invalid-name,unused-wildcard-import
#pylint: disable=wildcard-import,consider-using-enumerate,too-many-locals
#pylint: disable=too-many-branches,relative-import,len-as-condition

from xlate_sql_expr import *
from xlate_sql_expr_transform import expr_promote_to_nary

class ExprOptimizer(object):
    def __init__(self, expr):
        self._expr = expr


    def _opt_OR_expr(self, expr):
        # step 1: promote the n-ary OR expression
        changed = expr_promote_to_nary(expr)

        # step 2: go through all terms.
        new_opnds = []
        opnds = expr.get_opnds()

        for opnd_iter in opnds:
            assert isinstance(opnd_iter, Expr)
            simplifed_opnd, opnd_changed = self._optimize(opnd_iter)
            if opnd_changed:
                changed = True

            annot = simplifed_opnd.get_annot()
            if annot is not None:
                if annot.is_False():
                    # it's changed in the sense we redduce the # of terms
                    changed = True
                    continue

                if annot.is_True():
                    # then the entire expression is false
                    return simplifed_opnd, True

            # remove duplicated terms, Oops, this is O(n*n) complexity,
            # if it's too time consuming to be unacceptable, improve it.
            duplicated = False
            for _iter in new_opnds:
                if _iter == simplifed_opnd:
                    changed = True
                    duplicated = True
                    break

            if not duplicated:
                new_opnds.append(simplifed_opnd)

        if len(new_opnds) == 0:
            return get_false_expr(), True

        if not changed:
            return expr, False

        return gen_nary_or_expr(new_opnds), True


    def _opt_AND_expr(self, expr):
        # step 1: promote the n-ary AND expression
        changed = expr_promote_to_nary(expr)

        # step 2: go through all terms.
        new_opnds = []
        opnds = expr.get_opnds()

        for opnd_iter in opnds:
            assert isinstance(opnd_iter, Expr)
            simplifed_opnd, opnd_changed = self._optimize(opnd_iter)
            if opnd_changed:
                changed = True

            annot = simplifed_opnd.get_annot()
            if annot is not None:
                if annot.is_True():
                    # it's changed in the sense we reduce the # of terms
                    continue

                if annot.is_False():
                    # then the entire expression is false
                    return simplifed_opnd, True

            # remove duplicated terms, Oops, this is O(n*n) complexity,
            # if it's too time consuming to be unacceptable, improve it.
            duplicated = False
            for _iter in new_opnds:
                if _iter == simplifed_opnd:
                    changed = True
                    duplicated = True
                    break

            if not duplicated:
                new_opnds.append(simplifed_opnd)

        if len(new_opnds) == 0:
            return get_true_expr(), True

        if not changed:
            return expr, False

        return gen_nary_and_expr(new_opnds), True


    def _opt_cmp(self, expr):
        annot = expr.get_annot()
        if annot is not None and annot.is_constant():
            # already constant
            return expr, False


        opnd0 = expr.get_opnd0()
        opnd1 = expr.get_opnd1()

        if not isinstance(opnd0, ExprOpndLiteral) or \
           not isinstance(opnd1, ExprOpndLiteral):
            return expr, False

        opcode = expr.get_opr().get_opcode()
        if opcode == OPR_EQ and \
           isinstance(opnd0.get_literal(), int) and \
           isinstance(opnd1.get_literal(), int):
            annot = expr.get_or_create_annot()
            annot.set_folded_const(True if opnd0 == opnd1 else False)
            return expr, True

        return expr, False

    def _opt_unary(self, expr):
        # rule 1: not not expr = expr
        opc = expr.get_opr().get_opcode()
        if opc == OPR_NEG:
            if expr.get_opnd0().get_opr().get_opcode() == OPR_NEG:
                return expr.get_opnd0().get_opnd0(), True
        return expr, False


    def _misc_opt(self, expr):
        if not isinstance(expr, Expr):
            return expr, False

        opr = expr.get_opr()
        if opr.is_unary():
            return self._opt_unary(expr)

        opnds = expr.get_opnds()
        new_opnds = []
        changed = False

        i = 0
        while i < len(opnds):
            s_opnd, c = self._optimize(opnds[i])
            changed = True if c else changed
            new_opnds.append(s_opnd)
            i += 1

        opcode = expr.get_opr().get_opcode()
        if changed:
            expr = Expr(opcode, *new_opnds)

        if opcode in (OPR_EQ, OPR_LT, OPR_LTE, OPR_GT, OPR_GTE):
            return self._opt_cmp(expr)

        return expr, changed


    def _optimize(self, expr):
        if not isinstance(expr, Expr):
            return expr, False

        opr = expr.get_opr()
        opc = opr.get_opcode()

        # optimize OR expr
        if opc in (OPR_OR, OPR_N_OR):
            return self._opt_OR_expr(expr)

        # optimize AND expr
        if opc in (OPR_AND, OPR_N_AND):
            return self._opt_AND_expr(expr)

        # optimize other expr
        return self._misc_opt(expr)


    def optimize(self):
        if isinstance(self._expr, Expr):
            return self._optimize(self._expr)
        return self._expr, False


def optimize_expr(expr):
    return ExprOptimizer(expr).optimize()[0]
