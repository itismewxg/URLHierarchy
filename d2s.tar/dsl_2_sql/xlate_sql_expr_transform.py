#pylint: disable=missing-docstring,invalid-name,unused-wildcard-import
#pylint: disable=wildcard-import,consider-using-enumerate,too-many-locals
#pylint: disable=too-many-branches

from xlate_sql_expr import *

def _collect_term(expr):
    opcode = expr.get_opr().get_opcode()
    opcode_grp = [OPR_AND, OPR_N_AND]
    if opcode in [OPR_OR, OPR_N_OR]:
        opcode_grp = [OPR_OR, OPR_N_OR]

    collect_opnds = []
    opnds = expr.get_opnds()

    for opnd in opnds:
        if not isinstance(opnd, Expr) or \
           not opnd.get_opr().get_opcode() in opcode_grp:
            collect_opnds.append(opnd)
            continue

        opnd_terms = _collect_term(opnd)
        collect_opnds.extend(opnd_terms)

    return collect_opnds


def expr_promote_to_nary(expr):
    """
        transform the given express to use nary-and/or whereever possible.
        return True if the expr is (in-place) transformed or False otherwise.

        NOTE: the transformation is done in place
    """
    if not isinstance(expr, Expr):
        return False

    changed = False
    opr = expr.get_opr()

    if not opr.get_opcode() in (OPR_AND, OPR_OR, OPR_N_AND, OPR_N_OR):
        for opnd in expr.get_opnds():
            if expr_promote_to_nary(opnd):
                changed = True

        return changed

    opnds = _collect_term(expr)

    if len(opnds) == len(expr.get_opnds()):
        return False

    if opr.get_opcode() in (OPR_AND, OPR_N_AND):
        new_opr = ExprOpr(OPR_N_AND)
    else:
        new_opr = ExprOpr(OPR_N_OR)

    expr.set_opr_opnds(new_opr, opnds)
    return True


def _find_AND_term(expr, and_term, ignore_terms):
    """
    helper function of factor_out_common_AND_term(). It is to check if
    given and/nary-and expr contains the 'and_term', if so return the operand
    index; otherwise return None.

    ignore_terms is a array of indices of operands which should be ignored.
    """
    if not expr.get_opr().get_opcode() in (OPR_AND, OPR_N_AND):
        return

    opnds = expr.get_opnds()
    for opnd_idx in range(len(opnds)):
        if not ignore_terms[opnd_idx] and and_term == opnds[opnd_idx]:
            return opnd_idx


def factor_out_common_AND_term(and_expr_list):
    """
        if and-expressions in and_expr_list do not share common sub-expression,
        None is returned. Otherwise, returned the list the expression where
          o. i-th expr corresponds to the expression of and_expr_list[i] with
             common sub-expression being eliminated.
          o. the last element of the return value is the common-sub-expr

        e.g. given input ['a ^ b ^ x', 'a ^ b ^ y'], the return value will be
            ['x', 'y', 'a^b']
    """
    expr_num = len(and_expr_list)
    if expr_num <= 1:
        return

    # step 1: check all expression are n-ary-and expression
    for ei in and_expr_list:
        if not isinstance(ei, Expr) or \
           not ei.get_opr().get_opcode() in (OPR_AND, OPR_N_AND):
            return

    # step 2: allocate factor-out-map matrix, factor_out_map[i][j] == True
    #  indicate i-th expression's j-th AND-term is a common sub-expression
    #
    factor_out_map = [None] * expr_num
    for idx in range(expr_num):
        opnds = and_expr_list[idx].get_opnds()
        factor_out_map[idx] = [False] * len(opnds)

    # step 3: detect common sub-express. TODO: reduce algorithm complexcity.
    #
    and_terms = and_expr_list[0].get_opnds()
    common_subexprs = []

    # go through all and-terms of the 0-th expression
    for i_idx in range(len(and_terms)):
        and_term = and_terms[i_idx]

        sub_expr_vector = [-1] * expr_num
        is_common_subexpr = False
        for j_idx in range(1, expr_num):
            expr2 = and_expr_list[j_idx]
            common_term_idx = _find_AND_term(expr2, and_term, factor_out_map[j_idx])
            if common_term_idx is None:
                is_common_subexpr = False
                break
            else:
                is_common_subexpr = True
                sub_expr_vector[j_idx] = common_term_idx

        # The operand is a common and-term. Remember the index of this common
        # and-term in each expressions
        if is_common_subexpr:
            common_subexprs.append(and_term)
            factor_out_map[0][i_idx] = True
            for j_idx in range(1, expr_num):
                factor_out_map[j_idx][sub_expr_vector[j_idx]] = True

    if not common_subexprs:
        return

    # step 4: re-construct each nary-and expression with common and-terms eliminated
    result = [None] * (expr_num + 1)
    for idx in range(expr_num):
        expr = and_expr_list[idx]
        opnds = expr.get_opnds()
        common_expr_map = factor_out_map[idx]

        new_opnds = []
        for opnd_idx in range(len(opnds)):
            if not common_expr_map[opnd_idx]:
                new_opnds.append(opnds[opnd_idx])

        if new_opnds:
            result[idx] = gen_nary_and_expr(new_opnds)
        else:
            result[idx] = get_true_expr()


    result[-1] = gen_nary_and_expr(common_subexprs)
    return result
