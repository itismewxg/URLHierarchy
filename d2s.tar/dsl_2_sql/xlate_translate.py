#pylint: disable=missing-docstring,too-few-public-methods,bare-except,invalid-name
#pylint: disable=wrong-import-position,relative-import

import os
import sys
import json
import logging
logger = logging.getLogger(__name__)

rel_path = os.path.dirname(os.path.realpath(__file__))
if not rel_path in sys.path:
    sys.path.append(rel_path)

from xlate_aggr import AggrGroup
from xlate_non_aggr import NonAggregation

def DSL2SQL(dsl, ctx):
    try:
        if 'aggs' in dsl:
            return AggrGroup(dsl, ctx).emit_sql()
        return NonAggregation(dsl, ctx).emit_sql()
    except:
        msg = ("failed to translate following DSL to SQL for table '%s': %s") % (
            ctx.get_current_table(), json.dumps(dsl))
        logger.exception(msg)

        return None
