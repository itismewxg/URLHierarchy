import json

def get_single_kv_pair(dsl, ignore_key=None, expected_key=None):
    key_set = set(dsl.keys())
    if ignore_key is not None:
        key_set -= set(ignore_key)

    if not key_set or len(key_set) != 1:
        raise Exception("the dsl does not contain exactly one kv pair we care about")

    for ki in key_set:
        if expected_key is not None and \
           expected_key != ki:
            raise Exception("expect to see key %s" % expected_key)
        return ki, dsl[ki]


def get_single_value(dsl, key, ignore_key=None):
    k, v = get_single_kv_pair(dsl, ignore_key=ignore_key)
    if k != key:
        raise Exception("don't find expected key")
    return v


def not_supported(keyword, context=None):
    if context is not None:
        msg = "the keyword '%s' is not supported in the context of '%s'" % (\
            keyword, context)
    else:
        msg = "the keyword '%s' is not supported" % keyword

    raise Exception(msg)


def dsl_failed_to_parse(dsl):
    """
    raise exception complaining not able to parse given dsl
    """
    msg = "failed to parse %s" % json.dumps(dsl)
    raise Exception(msg)


def dsl_assert_key(dsl_blk, keys, exact=False):
    """
    assert given DSL blocks contains given keys
    """
    for ki in keys:
        if not ki in dsl_blk:
            msg = "cannot find key %s in the DSL: %s" % (ki, json.dumps(dsl_blk))
            raise Exception(msg)

    if exact:
        if set(keys) == set(dsl_blk.keys):
            msg = "unexpected key in %s" % (ki, json.dumps(dsl))
            raise Exception(msg)
